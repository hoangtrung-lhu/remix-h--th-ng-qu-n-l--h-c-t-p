import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // AI Assistant endpoint
  app.post("/api/ai-assistant", async (req, res) => {
    const { message, context, chatHistory } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Tin nhắn không hợp lệ" });
    }

    try {
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        // Fallback intelligent response if no API key is set
        const simulatedReply = generateFallbackResponse(message, context);
        return res.json({ reply: simulatedReply, fallback: true });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const systemPrompt = `Bạn là Trợ lý Học tập AI thông minh (EduLMS AI Tutor) dành cho học sinh, sinh viên Việt Nam.
Phong cách trả lời: Thân thiện, truyền cảm hứng, ngắn gọn, súc tích, định dạng markdown rõ ràng với emoji phù hợp.
Bạn có quyền truy cập vào thông tin học tập hiện tại của học viên:
- Học viên: ${context?.userName || 'Học viên'} (Trường: ${context?.school || 'THPT'}, Lớp: ${context?.grade || '12'})
- Các khóa học đang tham gia: ${JSON.stringify(context?.courses || [])}
- Các nhiệm vụ/bài tập sắp đến hạn: ${JSON.stringify(context?.tasks || [])}
- Lịch học sắp tới: ${JSON.stringify(context?.schedule || [])}
- Chuỗi ngày học (streak): ${context?.streak || 7} ngày

Nhiệm vụ của bạn:
1. Khi học viên hỏi "Hôm nay tôi cần học gì?" hoặc "Tóm tắt bài tập", hãy phân tích các nhiệm vụ còn hạn và lịch học sắp tới để đưa ra kế hoạch rõ ràng theo khung giờ.
2. Khi học viên hỏi kiến thức môn học (Toán, Lý, Hóa, Văn, Anh, Tin học...), hãy giải thích ngắn gọn, dễ hiểu, kèm công thức hoặc ví dụ minh họa trực quan.
3. Luôn động viên tinh thần học tập và khuyên học sinh cân bằng thời gian nghỉ ngơi hợp lý.
Trả lời hoàn toàn bằng tiếng Việt chuẩn.`;

      let promptContent = message;
      if (chatHistory && Array.isArray(chatHistory) && chatHistory.length > 0) {
        const historyText = chatHistory
          .slice(-6)
          .map((h: { sender: string; text: string }) => `${h.sender === 'user' ? 'Học viên' : 'Trợ lý'}: ${h.text}`)
          .join('\n');
        promptContent = `Lịch sử cuộc trò chuyện:\n${historyText}\n\nHọc viên hỏi: ${message}`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: promptContent,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7,
        },
      });

      const replyText = response.text || "Xin lỗi, tôi chưa thể trả lời câu hỏi này lúc này. Bạn vui lòng thử lại nhé!";
      return res.json({ reply: replyText });
    } catch (error) {
      console.error("AI Assistant API Error:", error);
      const fallbackReply = generateFallbackResponse(message, context);
      return res.json({ reply: fallbackReply, fallback: true });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server LMS running at http://0.0.0.0:${PORT}`);
  });
}

function generateFallbackResponse(msg: string, context: any): string {
  const lower = msg.toLowerCase();
  const userName = context?.userName || 'Bạn';

  if (lower.includes('hôm nay') || lower.includes('học gì') || lower.includes('kế hoạch')) {
    const pendingTasks = context?.tasks?.filter((t: any) => t.status !== 'completed') || [];
    const urgentTask = pendingTasks[0];
    return `Chào ${userName}! 🎯 Dưới đây là gợi ý lộ trình học tập tối ưu hôm nay:

1. ⚡ **Ưu tiên số 1:** ${urgentTask ? `Hoàn thành bài tập **"${urgentTask.title}"** (Hạn chót: ${urgentTask.dueDate})` : 'Ôn tập chuyên đề Toán học & Đọc tài liệu Vật lý'}.
2. 📖 **Tiếp tục bài học:** Vào khóa học **Toán 12** học tiếp bài giảng Khảo sát hàm số.
3. 🧘 **Nghỉ ngơi 15 phút (Pomodoro):** Uống nước và thư giãn mắt sau mỗi 45 phút học tập.

Chúc bạn có một buổi học thật hiệu quả và giữ vững chuỗi ${context?.streak || 7} ngày học liên tiếp nhé! 🔥`;
  }

  if (lower.includes('bài tập') || lower.includes('hạn') || lower.includes('deadline')) {
    const tasks = context?.tasks || [];
    const pending = tasks.filter((t: any) => t.status !== 'completed');
    if (pending.length === 0) {
      return `🎉 Tuyệt vời ${userName}! Bạn đã hoàn thành toàn bộ bài tập và không còn nhiệm vụ nào quá hạn. Bạn có thể dành thời gian đọc thêm sách hoặc học bài mới!`;
    }
    const list = pending.slice(0, 3).map((t: any, i: number) => `${i + 1}. **${t.title}** (${t.subject}) - Hạn: ${t.dueDate} [Độ ưu tiên: ${t.priority}]`).join('\n');
    return `📋 **Tổng hợp bài tập còn hạn (${pending.length} nhiệm vụ):**\n\n${list}\n\n👉 *Lời khuyên:* Hãy xử lý bài tập có độ ưu tiên **Cao** trước để giảm áp lực nhé!`;
  }

  if (lower.includes('công thức') || lower.includes('toán') || lower.includes('đạo hàm')) {
    return `📐 **Tóm tắt công thức Đạo hàm cơ bản thường gặp:**

- $(x^n)' = n \\cdot x^{n-1}$
- $(\\sin x)' = \\cos x$ ; $(\\cos x)' = -\\sin x$
- $(\\tan x)' = \\frac{1}{\\cos^2 x}$
- $(e^x)' = e^x$ ; $(\\ln x)' = \\frac{1}{x}$
- Đạo hàm hàm hợp: $[f(u)]' = f'(u) \\cdot u'$

💡 Cần mình hỗ trợ giải bài tập cụ thể nào, bạn cứ nhắn đề bài nhé!`;
  }

  return `Chào ${userName}! 🌟 Mình là **Trợ lý Học tập AI (EduLMS)**. Mình có thể giúp bạn:
- 📌 Tổng hợp & phân bổ lịch học, bài tập thông minh
- 📖 Giải thích kiến thức các môn Toán, Lý, Hóa, Tiếng Anh, Văn, Tin...
- ⏱️ Lập kế hoạch ôn thi bứt phá điểm số

Bạn muốn mình hỗ trợ nội dung nào ngay bây giờ?`;
}

startServer().catch(console.error);
