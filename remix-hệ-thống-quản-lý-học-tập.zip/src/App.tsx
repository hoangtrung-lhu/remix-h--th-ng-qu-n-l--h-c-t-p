import React from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import { Sidebar } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { ToastContainer } from '@/components/ToastContainer';
import { AIAssistantModal } from '@/components/AIAssistantModal';
import { CourseDetailModal } from '@/components/CourseDetailModal';
import { LessonPlayerModal } from '@/components/LessonPlayerModal';
import { EnrollCourseModal } from '@/components/EnrollCourseModal';
import { NewTaskModal } from '@/components/NewTaskModal';
import { NewEventModal } from '@/components/NewEventModal';

import { DashboardView } from '@/views/DashboardView';
import { CoursesView } from '@/views/CoursesView';
import { ScheduleView } from '@/views/ScheduleView';
import { TasksView } from '@/views/TasksView';
import { NotificationsView } from '@/views/NotificationsView';
import { SettingsView } from '@/views/SettingsView';
import { AuthView } from '@/views/AuthView';

import {
  LayoutDashboard,
  BookOpen,
  Calendar,
  CheckSquare,
  Bell,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const MainLayout: React.FC = () => {
  const { isAuthenticated, currentView, setCurrentView } = useApp();

  if (!isAuthenticated) {
    return <AuthView />;
  }

  const getViewTitle = () => {
    switch (currentView) {
      case 'dashboard':
        return 'Bảng Điều Khiển Học Tập';
      case 'courses':
        return 'Khóa Học & Chuyên Đề';
      case 'schedule':
        return 'Thời Khóa Biểu & Lịch Học';
      case 'tasks':
        return 'Nhiệm Vụ & Bài Tập (Kanban)';
      case 'notifications':
        return 'Thông Báo Hệ Thống';
      case 'profile':
      case 'settings':
        return 'Hồ Sơ & Cài Đặt';
      default:
        return 'Bảng Điều Khiển';
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />;
      case 'courses':
        return <CoursesView />;
      case 'schedule':
        return <ScheduleView />;
      case 'tasks':
        return <TasksView />;
      case 'notifications':
        return <NotificationsView />;
      case 'profile':
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F4EF] dark:bg-[#14161F] text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row transition-colors duration-200">
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen pb-16 lg:pb-0">
        <Header title={getViewTitle()} />

        <main className="flex-1 p-4 sm:p-6 md:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              {renderCurrentView()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-[#1C1F2E] border-t border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-around px-2 z-40">
        <button
          onClick={() => setCurrentView('dashboard')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-medium transition-colors ${
            currentView === 'dashboard'
              ? 'text-[#3E4C82] dark:text-[#8D81F2] font-bold'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <LayoutDashboard size={18} />
          <span>Tổng quan</span>
        </button>

        <button
          onClick={() => setCurrentView('courses')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-medium transition-colors ${
            currentView === 'courses'
              ? 'text-[#3E4C82] dark:text-[#8D81F2] font-bold'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <BookOpen size={18} />
          <span>Khóa học</span>
        </button>

        <button
          onClick={() => setCurrentView('schedule')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-medium transition-colors ${
            currentView === 'schedule'
              ? 'text-[#3E4C82] dark:text-[#8D81F2] font-bold'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <Calendar size={18} />
          <span>Lịch học</span>
        </button>

        <button
          onClick={() => setCurrentView('tasks')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-medium transition-colors ${
            currentView === 'tasks'
              ? 'text-[#3E4C82] dark:text-[#8D81F2] font-bold'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <CheckSquare size={18} />
          <span>Bài tập</span>
        </button>

        <button
          onClick={() => setCurrentView('profile')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-medium transition-colors ${
            currentView === 'profile' || currentView === 'settings'
              ? 'text-[#3E4C82] dark:text-[#8D81F2] font-bold'
              : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <User size={18} />
          <span>Cá nhân</span>
        </button>
      </div>

      {/* Interactive Global Modals */}
      <CourseDetailModal />
      <LessonPlayerModal />
      <EnrollCourseModal />
      <NewTaskModal />
      <NewEventModal />
      <AIAssistantModal />

      {/* Global Toast Notifications */}
      <ToastContainer />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

export default App;
