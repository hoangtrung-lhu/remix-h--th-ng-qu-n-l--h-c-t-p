import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User,
  Trash2,
  Minimize2,
  RefreshCw,
  Lightbulb
} from 'lucide-react';
import { AIChatMessage } from '@/types';
import { motion, AnimatePresence } from 'motion/react';

const SUGGESTED_PROMPTS = [
  '📌 Hôm nay tôi cần học gì?',
  '📋 Tóm tắt bài tập còn hạn',
  '📐 Tóm tắt công thức Đạo hàm',
  '🗓️ Lên kế hoạch ôn tập 3 ngày tới'
];

export const AIAssistantModal: React.FC = () => {
  const {
    isAIAssistantOpen,
    setIsAIAssistantOpen,
    user,
    courses,
    tasks,
    scheduleEvents
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: `Xin chào **${user.name}**! 👋 Mình là **Gia sư Trợ lý AI EduLMS**.\n\nMình có thể giúp bạn theo dõi bài tập còn hạn, lập kế hoạch ôn thi, hoặc giải đáp các thắc mắc về môn Toán, Lý, Hóa, Tiếng Anh, Ngữ văn... Bạn cần mình hỗ trợ gì hôm nay?`,
      timestamp: 'Vừa xong',
      suggestions: SUGGESTED_PROMPTS
    }
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isAIAssistantOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isAIAssistantOpen, loading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || loading) return;

    const userMsg: AIChatMessage = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setLoading(true);

    try {
      // Gather context
      const contextData = {
        userName: user.name,
        school: user.school,
        grade: user.grade,
        streak: user.streakDays,
        courses: courses.map(c => ({
          title: c.title,
          subject: c.subject,
          progress: c.progress,
          completedLessons: c.completedLessons,
          totalLessons: c.totalLessons
        })),
        tasks: tasks.map(t => ({
          title: t.title,
          subject: t.subject,
          dueDate: t.dueDate,
          priority: t.priority,
          status: t.status
        })),
        schedule: scheduleEvents.map(s => ({
          title: s.title,
          subject: s.subject,
          date: s.date,
          startTime: s.startTime,
          endTime: s.endTime,
          type: s.type
        }))
      };

      const res = await fetch('/api/ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          context: contextData,
          chatHistory: messages.slice(-5)
        })
      });

      const data = await res.json();
      const replyText = data.reply || 'Xin lỗi, tôi gặp chút gián đoạn. Bạn thử lại nhé!';

      const aiMsg: AIChatMessage = {
        id: 'msg_ai_' + Date.now(),
        sender: 'assistant',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error('Error calling AI assistant:', err);
      const errorMsg: AIChatMessage = {
        id: 'msg_err_' + Date.now(),
        sender: 'assistant',
        text: '⚠️ Không thể kết nối với máy chủ AI. Vui lòng kiểm tra kết nối và thử lại!',
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: 'msg_welcome_' + Date.now(),
        sender: 'assistant',
        text: `Đã làm mới cuộc hội thoại! Bạn muốn trao đổi về bài tập hay môn học nào cùng mình tiếp theo nhé? 📚`,
        timestamp: 'Vừa xong',
        suggestions: SUGGESTED_PROMPTS
      }
    ]);
  };

  return (
    <>
      {/* Floating Action Button (FAB) */}
      {!isAIAssistantOpen && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsAIAssistantOpen(true)}
          className="fixed bottom-6 right-6 z-40 p-3.5 bg-[#7C6FE3] hover:bg-[#6A5CD6] text-white rounded-full shadow-xl shadow-[#7C6FE3]/30 border-2 border-white/20 flex items-center gap-2 group transition-all"
          title="Mở Trợ lý học tập AI"
          aria-label="Mở Trợ lý học tập AI"
        >
          <div className="relative">
            <Sparkles size={22} className="animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#E2A33D] rounded-full ring-2 ring-[#7C6FE3]" />
          </div>
          <span className="hidden sm:inline font-heading font-bold text-xs pr-1">
            Trợ lý AI
          </span>
        </motion.button>
      )}

      {/* AI Chat Drawer / Modal */}
      <AnimatePresence>
        {isAIAssistantOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-end sm:p-6 pointer-events-none">
            {/* Backdrop on mobile */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAIAssistantOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-xs sm:hidden pointer-events-auto"
            />

            {/* Chat Box */}
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.95 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="pointer-events-auto w-full sm:w-[460px] h-[85vh] sm:h-[620px] max-h-screen bg-white dark:bg-[#1C1F2E] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-[#E2E0D8] dark:border-[#2D3349] flex flex-col overflow-hidden relative"
            >
              {/* Header */}
              <div className="px-5 py-4 bg-gradient-to-r from-[#262F52] to-[#3E4C82] text-white flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-[#7C6FE3] flex items-center justify-center shadow-inner border border-white/20">
                    <Bot size={22} className="text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-bold font-heading text-sm text-white">
                        EduLMS AI Tutor
                      </h3>
                      <span className="px-1.5 py-0.5 bg-[#7C6FE3]/40 text-[10px] font-bold rounded-md font-mono">
                        AI 3.7
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
                      Sẵn sàng hỗ trợ học viên
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={handleClearHistory}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Xóa lịch sử trò chuyện"
                  >
                    <Trash2 size={16} />
                  </button>
                  <button
                    onClick={() => setIsAIAssistantOpen(false)}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Thu nhỏ"
                  >
                    <Minimize2 size={16} />
                  </button>
                  <button
                    onClick={() => setIsAIAssistantOpen(false)}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors sm:hidden"
                    title="Đóng"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>

              {/* Chat Message List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 dark:bg-[#14161F]/70">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-2.5 ${
                      msg.sender === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {msg.sender === 'assistant' && (
                      <div className="w-7 h-7 rounded-xl bg-[#7C6FE3] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                        <Bot size={15} />
                      </div>
                    )}

                    <div
                      className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-[#3E4C82] text-white rounded-tr-xs shadow-sm font-medium'
                          : 'bg-white dark:bg-[#1C1F2E] text-slate-800 dark:text-slate-200 border border-[#E2E0D8] dark:border-[#2D3349] rounded-tl-xs shadow-sm'
                      }`}
                    >
                      {/* Formatted body text */}
                      <div className="whitespace-pre-wrap font-sans space-y-1.5">
                        {msg.text.split('\n').map((line, idx) => {
                          if (line.startsWith('### ')) {
                            return <p key={idx} className="font-bold text-sm font-heading mt-2 mb-1 text-[#7C6FE3] dark:text-[#A499FF]">{line.replace('### ', '')}</p>;
                          }
                          if (line.startsWith('- ') || line.startsWith('* ')) {
                            return <p key={idx} className="pl-2 border-l-2 border-[#7C6FE3]/40">{line}</p>;
                          }
                          return <p key={idx}>{line}</p>;
                        })}
                      </div>

                      {/* Timestamp */}
                      <span
                        className={`text-[9px] font-mono mt-1.5 block text-right ${
                          msg.sender === 'user'
                            ? 'text-white/60'
                            : 'text-slate-400 dark:text-slate-500'
                        }`}
                      >
                        {msg.timestamp}
                      </span>

                      {/* Prompt Suggestions */}
                      {msg.suggestions && msg.suggestions.length > 0 && (
                        <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 space-y-1.5">
                          <p className="text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                            <Lightbulb size={11} className="text-[#E2A33D]" />
                            Gợi ý câu hỏi nhanh:
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {msg.suggestions.map((sug, i) => (
                              <button
                                key={i}
                                onClick={() => handleSendMessage(sug)}
                                className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-[#7C6FE3]/15 hover:text-[#7C6FE3] dark:hover:text-[#A499FF] text-slate-700 dark:text-slate-300 font-medium transition-all text-left border border-slate-200 dark:border-slate-700/60"
                              >
                                {sug}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {msg.sender === 'user' && (
                      <div className="w-7 h-7 rounded-xl bg-[#3E4C82] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                        <User size={15} />
                      </div>
                    )}
                  </div>
                ))}

                {/* Loading indicator */}
                {loading && (
                  <div className="flex gap-2.5 justify-start">
                    <div className="w-7 h-7 rounded-xl bg-[#7C6FE3] text-white flex items-center justify-center shrink-0 mt-0.5">
                      <Bot size={15} />
                    </div>
                    <div className="bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] p-3 rounded-2xl rounded-tl-xs shadow-sm flex items-center gap-2">
                      <RefreshCw size={14} className="animate-spin text-[#7C6FE3]" />
                      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        AI Tutor đang phân tích dữ liệu và suy nghĩ...
                      </span>
                    </div>
                  </div>
                )}

                <div ref={chatEndRef} />
              </div>

              {/* Input Footer */}
              <div className="p-3 bg-white dark:bg-[#1C1F2E] border-t border-[#E2E0D8] dark:border-[#2D3349]">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage();
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Hỏi AI bài tập, môn học, lịch trình..."
                    disabled={loading}
                    className="flex-1 px-4 py-2.5 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#7C6FE3]/30 focus:border-[#7C6FE3] transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!inputMessage.trim() || loading}
                    className="p-2.5 bg-[#7C6FE3] hover:bg-[#6A5CD6] disabled:opacity-40 disabled:hover:bg-[#7C6FE3] text-white rounded-xl transition-all shadow-md active:scale-95 shrink-0"
                    aria-label="Gửi tin nhắn"
                  >
                    <Send size={16} />
                  </button>
                </form>
                <p className="text-[10px] text-center text-slate-400 dark:text-slate-500 mt-1.5 font-medium">
                  Trợ lý AI hỗ trợ học tập dựa trên dữ liệu thật của bạn.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
