import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  X,
  BookOpen,
  Clock,
  Star,
  PlayCircle,
  CheckCircle2,
  Lock,
  Play,
  Award
} from 'lucide-react';
import { motion } from 'motion/react';

export const CourseDetailModal: React.FC = () => {
  const { selectedCourse, setSelectedCourse, setActiveLesson } = useApp();

  if (!selectedCourse) return null;

  const course = selectedCourse;

  // Find first in-progress or not-started lesson
  const allLessons = course.chapters.flatMap(ch => ch.lessons);
  const nextLessonToLearn =
    allLessons.find(l => l.status === 'in_progress') ||
    allLessons.find(l => l.status === 'not_started') ||
    allLessons[0];

  const handleStartLesson = (lesson: any) => {
    setActiveLesson({ course, lesson });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
        onClick={() => setSelectedCourse(null)}
      />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-4xl bg-white dark:bg-[#1C1F2E] rounded-3xl shadow-2xl border border-[#E2E0D8] dark:border-[#2D3349] overflow-hidden flex flex-col max-h-[90vh] z-10"
      >
        {/* Banner Section */}
        <div className="relative h-48 sm:h-56 bg-slate-900 overflow-hidden shrink-0">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover opacity-40 filter blur-2xs"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={() => setSelectedCourse(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors z-10"
            aria-label="Đóng chi tiết khóa học"
          >
            <X size={20} />
          </button>

          {/* Banner Info */}
          <div className="absolute bottom-4 left-4 sm:left-6 right-4 sm:right-6 text-white">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#E2A33D] text-slate-950 text-xs font-bold font-mono">
                {course.subject}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-xs font-mono backdrop-blur-md">
                {course.code}
              </span>
            </div>
            <h2 className="text-lg sm:text-2xl font-bold font-heading text-white line-clamp-2">
              {course.title}
            </h2>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                <BookOpen size={16} />
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Tổng bài học</p>
                <p className="text-xs font-bold font-mono text-slate-800 dark:text-slate-200">
                  {course.completedLessons}/{course.totalLessons} bài
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <Clock size={16} />
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Thời lượng</p>
                <p className="text-xs font-bold font-mono text-slate-800 dark:text-slate-200">
                  {course.durationHours} giờ học
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                <Award size={16} />
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Tiến độ</p>
                <p className="text-xs font-bold font-mono text-[#3E4C82] dark:text-[#8D81F2]">
                  {course.progress}%
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-yellow-500/10 text-yellow-500 flex items-center justify-center">
                <Star size={16} className="fill-yellow-500" />
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Đánh giá</p>
                <p className="text-xs font-bold font-mono text-slate-800 dark:text-slate-200">
                  {course.rating} ({course.reviewCount})
                </p>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Tiến trình hoàn thành khóa học
              </span>
              <span className="font-bold text-[#3E4C82] dark:text-[#8D81F2] font-mono">
                {course.progress}%
              </span>
            </div>
            <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#3E4C82] dark:bg-[#8D81F2] rounded-full transition-all duration-500 ease-out"
                style={{ width: `${course.progress}%` }}
              />
            </div>
          </div>

          {/* Instructor & Description */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-2">
              <h3 className="font-bold font-heading text-sm text-slate-900 dark:text-white">
                Mô tả khóa học
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {course.description}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-[#E2E0D8] dark:border-[#2D3349] flex items-center gap-3">
              <img
                src={course.instructor.avatar}
                alt={course.instructor.name}
                className="w-12 h-12 rounded-xl object-cover ring-2 ring-[#3E4C82]/20"
              />
              <div>
                <p className="text-[11px] text-slate-400 font-medium">Giảng viên phụ trách</p>
                <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                  {course.instructor.name}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {course.instructor.title}
                </p>
              </div>
            </div>
          </div>

          {/* Chapter / Curriculum Breakdown */}
          <div className="space-y-4">
            <h3 className="font-bold font-heading text-base text-slate-900 dark:text-white flex items-center justify-between">
              <span>Chương trình học ({course.chapters.length} chương)</span>
              <span className="text-xs font-normal text-slate-500 font-mono">
                {allLessons.length} bài học
              </span>
            </h3>

            <div className="space-y-3">
              {course.chapters.map((chapter) => (
                <div
                  key={chapter.id}
                  className="rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349] overflow-hidden bg-white dark:bg-[#1C1F2E]"
                >
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border-b border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-between">
                    <h4 className="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-200">
                      {chapter.title}
                    </h4>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {chapter.lessons.length} bài
                    </span>
                  </div>

                  <div className="divide-y divide-slate-100 dark:divide-slate-800/70">
                    {chapter.lessons.map((lesson) => {
                      const isCompleted = lesson.status === 'completed';
                      const isInProgress = lesson.status === 'in_progress';

                      return (
                        <div
                          key={lesson.id}
                          onClick={() => handleStartLesson(lesson)}
                          className="p-3.5 sm:p-4 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors cursor-pointer group"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="shrink-0">
                              {isCompleted ? (
                                <CheckCircle2 size={18} className="text-[#6E9E72]" />
                              ) : isInProgress ? (
                                <PlayCircle size={18} className="text-[#E2A33D] animate-pulse" />
                              ) : (
                                <BookOpen size={18} className="text-slate-400 group-hover:text-[#3E4C82]" />
                              )}
                            </div>
                            <div className="min-w-0">
                              <p className={`text-xs sm:text-sm font-semibold truncate ${
                                isCompleted
                                  ? 'text-slate-700 dark:text-slate-300'
                                  : isInProgress
                                  ? 'text-[#3E4C82] dark:text-[#8D81F2]'
                                  : 'text-slate-800 dark:text-slate-200'
                              }`}>
                                {lesson.title}
                              </p>
                              <span className="text-[11px] text-slate-400 font-mono">
                                {lesson.durationMinutes} phút • {lesson.type === 'video' ? 'Video bài giảng' : 'Tài liệu đọc'}
                              </span>
                            </div>
                          </div>

                          <button className={`px-3 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
                            isCompleted
                              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                              : isInProgress
                              ? 'bg-[#E2A33D]/20 text-[#C88E32] dark:text-[#E2A33D]'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 group-hover:bg-[#3E4C82] group-hover:text-white'
                          }`}>
                            {isCompleted ? 'Học lại' : isInProgress ? 'Tiếp tục' : 'Học ngay'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-white dark:bg-[#1C1F2E] border-t border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-between gap-4 shrink-0">
          <button
            onClick={() => setSelectedCourse(null)}
            className="px-4 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Đóng
          </button>

          {nextLessonToLearn && (
            <button
              onClick={() => handleStartLesson(nextLessonToLearn)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#3E4C82]/20 transition-all active:scale-95"
            >
              <Play size={16} />
              <span>Tiếp tục học: {nextLessonToLearn.title}</span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
