import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Search, BookOpen, Star, Plus, Check } from 'lucide-react';
import { motion } from 'motion/react';

export const EnrollCourseModal: React.FC = () => {
  const {
    isEnrollModalOpen,
    setIsEnrollModalOpen,
    catalogList,
    courses,
    enrollCourse
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('Tất cả');

  if (!isEnrollModalOpen) return null;

  const subjects = ['Tất cả', 'Sinh học', 'Lịch sử', 'Tổng hợp'];

  const filteredCatalog = catalogList.filter((course) => {
    const matchSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchSubject =
      selectedSubject === 'Tất cả' || course.subject === selectedSubject;
    return matchSearch && matchSubject;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
        onClick={() => setIsEnrollModalOpen(false)}
      />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-4xl bg-white dark:bg-[#1C1F2E] rounded-3xl shadow-2xl border border-[#E2E0D8] dark:border-[#2D3349] overflow-hidden flex flex-col max-h-[88vh] z-10"
      >
        {/* Header */}
        <div className="p-6 bg-[#262F52] text-white flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg sm:text-xl font-bold font-heading text-white">
              Đăng Ký Khóa Học Mới
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Khám phá và ghi danh vào các chuyên đề ôn thi chất lượng cao
            </p>
          </div>
          <button
            onClick={() => setIsEnrollModalOpen(false)}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            aria-label="Đóng modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Filters */}
        <div className="p-4 sm:p-6 bg-slate-50 dark:bg-slate-900/60 border-b border-[#E2E0D8] dark:border-[#2D3349] flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo tên môn, mã khóa, kiến thức..."
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-[#1C1F2E] border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#3E4C82]"
            />
          </div>

          <div className="flex gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {subjects.map((sub) => (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedSubject === sub
                    ? 'bg-[#3E4C82] text-white shadow-sm'
                    : 'bg-white dark:bg-[#1C1F2E] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>

        {/* Catalog Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {filteredCatalog.length === 0 ? (
            <div className="p-12 text-center text-slate-400">
              <BookOpen size={40} className="mx-auto text-slate-300 mb-3" />
              <p className="text-sm font-semibold">Không tìm thấy khóa học phù hợp</p>
              <p className="text-xs text-slate-400 mt-1">Vui lòng thử từ khóa tìm kiếm khác</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              {filteredCatalog.map((item) => {
                const isAlreadyEnrolled = courses.some((c) => c.id === item.id);

                return (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-[#1C1F2E] rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349] p-4 sm:p-5 flex flex-col justify-between hover:shadow-lg transition-shadow group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-slate-100">
                          <img
                            src={item.thumbnail}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="px-2 py-0.5 rounded-md bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] text-[10px] font-bold font-mono">
                              {item.subject}
                            </span>
                            <div className="flex items-center gap-0.5 text-yellow-500 text-[11px] font-bold font-mono">
                              <Star size={11} className="fill-yellow-500" />
                              <span>{item.rating}</span>
                            </div>
                          </div>
                          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white line-clamp-2">
                            {item.title}
                          </h3>
                        </div>
                      </div>

                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                        {item.description}
                      </p>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                        <span>Giảng viên: {item.instructor.name}</span>
                        <span>{item.totalLessons} bài học</span>
                      </div>
                    </div>

                    <button
                      disabled={isAlreadyEnrolled}
                      onClick={() => {
                        enrollCourse(item.id);
                        setIsEnrollModalOpen(false);
                      }}
                      className={`w-full py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all ${
                        isAlreadyEnrolled
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                          : 'bg-[#3E4C82] hover:bg-[#323D6B] text-white shadow-md shadow-[#3E4C82]/20 active:scale-95'
                      }`}
                    >
                      {isAlreadyEnrolled ? (
                        <>
                          <Check size={16} className="text-emerald-500" />
                          <span>Đã ghi danh</span>
                        </>
                      ) : (
                        <>
                          <Plus size={16} />
                          <span>Đăng ký học ngay (Miễn phí)</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
