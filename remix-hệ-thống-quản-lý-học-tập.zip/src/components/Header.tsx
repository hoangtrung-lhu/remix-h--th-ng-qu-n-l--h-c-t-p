import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Bell,
  Menu,
  Sun,
  Moon,
  Sparkles,
  CheckCircle2,
  Clock,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  title: string;
}

export const Header: React.FC<HeaderProps> = ({ title }) => {
  const {
    darkMode,
    toggleDarkMode,
    user,
    unreadNotificationCount,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    setCurrentView,
    setMobileMenuOpen,
    setIsAIAssistantOpen
  } = useApp();

  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [timeStr, setTimeStr] = useState('');

  // Clock with IBM Plex Mono font
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      const secs = String(now.getSeconds()).padStart(2, '0');
      setTimeStr(`${hours}:${mins}:${secs}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-16 bg-white dark:bg-[#1C1F2E] border-b border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30 transition-colors duration-200">
      {/* Left section: Hamburger & Title */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={() => setMobileMenuOpen(true)}
          className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
          aria-label="Mở menu"
        >
          <Menu size={20} />
        </button>
        <div>
          <h1 className="text-lg sm:text-xl font-bold font-heading text-slate-900 dark:text-white tracking-tight">
            {title}
          </h1>
        </div>
      </div>

      {/* Center/Right section */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Real-time Clock display with IBM Plex Mono font */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800/80 rounded-lg text-xs font-mono font-medium text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700/60">
          <Clock size={13} className="text-[#3E4C82] dark:text-[#8D81F2]" />
          <span>{timeStr}</span>
        </div>

        {/* AI Quick Prompt Button */}
        <button
          onClick={() => setIsAIAssistantOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-[#7C6FE3]/10 text-[#7C6FE3] dark:text-[#A499FF] dark:bg-[#7C6FE3]/20 hover:bg-[#7C6FE3]/20 transition-all border border-[#7C6FE3]/30 active:scale-95"
          title="Trợ lý học tập AI"
        >
          <Sparkles size={14} className="animate-pulse text-[#7C6FE3]" />
          <span className="hidden sm:inline">Hỏi AI Tutor</span>
        </button>

        {/* Theme Toggle (Sáng / Tối) */}
        <button
          onClick={toggleDarkMode}
          className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
          title={darkMode ? 'Chuyển sang chế độ Sáng' : 'Chuyển sang chế độ Tối'}
          aria-label="Chuyển chế độ sáng tối"
        >
          {darkMode ? (
            <Sun size={19} className="text-[#E2A33D]" />
          ) : (
            <Moon size={19} className="text-[#3E4C82]" />
          )}
        </button>

        {/* Notification Bell with Dropdown */}
        <div className="relative">
          <button
            onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
            className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors relative"
            aria-label="Xem thông báo"
          >
            <Bell size={19} />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#C56464] text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white dark:ring-[#1C1F2E] font-mono">
                {unreadNotificationCount}
              </span>
            )}
          </button>

          <AnimatePresence>
            {notifDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setNotifDropdownOpen(false)}
                />
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-[#1C1F2E] rounded-2xl shadow-xl border border-[#E2E0D8] dark:border-[#2D3349] z-50 overflow-hidden"
                >
                  <div className="p-4 border-b border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-between">
                    <div>
                      <h3 className="font-bold font-heading text-sm text-slate-900 dark:text-white">
                        Thông báo
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Bạn có {unreadNotificationCount} thông báo chưa đọc
                      </p>
                    </div>
                    {unreadNotificationCount > 0 && (
                      <button
                        onClick={markAllNotificationsAsRead}
                        className="text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline"
                      >
                        Đọc tất cả
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 text-xs">
                        Không có thông báo nào.
                      </div>
                    ) : (
                      notifications.slice(0, 4).map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => {
                            markNotificationAsRead(notif.id);
                            if (notif.actionView) {
                              setCurrentView(notif.actionView);
                            }
                            setNotifDropdownOpen(false);
                          }}
                          className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer flex gap-3 items-start ${
                            !notif.read ? 'bg-[#3E4C82]/5 dark:bg-[#5162A6]/10' : ''
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] flex items-center justify-center shrink-0 mt-0.5">
                            {notif.type === 'assignment' ? (
                              <BookOpen size={14} />
                            ) : notif.type === 'achievement' ? (
                              <CheckCircle2 size={14} />
                            ) : (
                              <Bell size={14} />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                              {notif.title}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                              {notif.message}
                            </p>
                            <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                              {notif.timeAgo}
                            </span>
                          </div>
                          {!notif.read && (
                            <span className="w-2 h-2 rounded-full bg-[#3E4C82] dark:bg-[#8D81F2] shrink-0 mt-1.5" />
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border-t border-[#E2E0D8] dark:border-[#2D3349] text-center">
                    <button
                      onClick={() => {
                        setCurrentView('notifications');
                        setNotifDropdownOpen(false);
                      }}
                      className="text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline"
                    >
                      Xem tất cả thông báo
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* User Pill */}
        <div
          onClick={() => setCurrentView('profile')}
          className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-[#E2E0D8] dark:border-[#2D3349] cursor-pointer group"
        >
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#3E4C82] dark:group-hover:text-[#8D81F2] transition-colors leading-tight">
              {user.name}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {user.grade}
            </p>
          </div>
          <img
            src={user.avatar}
            alt={user.name}
            className="w-9 h-9 rounded-full object-cover ring-2 ring-[#3E4C82]/20 dark:ring-[#8D81F2]/30 group-hover:ring-[#3E4C82] transition-all"
          />
        </div>
      </div>
    </header>
  );
};
