import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  X,
  Play,
  Pause,
  CheckCircle2,
  BookOpen,
  HelpCircle,
  Award,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';

export const LessonPlayerModal: React.FC = () => {
  const { activeLesson, setActiveLesson, updateLessonStatus, setIsAIAssistantOpen } = useApp();

  const [activeTab, setActiveTab] = useState<'content' | 'takeaways' | 'quiz'>('content');
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoProgress, setVideoProgress] = useState(35);
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  if (!activeLesson) return null;

  const { course, lesson } = activeLesson;

  // Find current lesson index and next/prev
  const allLessons = course.chapters.flatMap(ch => ch.lessons);
  const currentIndex = allLessons.findIndex(l => l.id === lesson.id);
  const prevLesson = currentIndex > 0 ? allLessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < allLessons.length - 1 ? allLessons[currentIndex + 1] : null;

  const handleMarkComplete = () => {
    updateLessonStatus(course.id, lesson.id, 'completed');
    if (nextLesson) {
      setActiveLesson({ course, lesson: nextLesson });
      setQuizSubmitted(false);
      setSelectedQuizOption(null);
    } else {
      setActiveLesson(null);
    }
  };

  const handleQuizSelect = (index: number) => {
    if (!quizSubmitted) {
      setSelectedQuizOption(index);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
        onClick={() => setActiveLesson(null)}
      />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl bg-white dark:bg-[#1C1F2E] rounded-3xl shadow-2xl border border-[#E2E0D8] dark:border-[#2D3349] overflow-hidden flex flex-col max-h-[92vh] z-10"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#262F52] text-white flex items-center justify-between shrink-0">
          <div className="min-w-0 pr-4">
            <div className="flex items-center gap-2 text-xs text-slate-300 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-white/15 font-semibold text-[#E2A33D]">
                {course.subject}
              </span>
              <span>•</span>
              <span className="truncate">{course.title}</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold font-heading text-white truncate">
              {lesson.title}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAIAssistantOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-[#7C6FE3] text-white hover:bg-[#6A5CD6] transition-colors"
              title="Hỏi AI về bài học này"
            >
              <Sparkles size={13} />
              <span>Hỏi AI về bài này</span>
            </button>
            <button
              onClick={() => setActiveLesson(null)}
              className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
              aria-label="Đóng bài học"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Video Simulator / Lecture Banner */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 aspect-video max-h-80 sm:max-h-96 w-full flex flex-col justify-between p-4 shadow-lg group">
            {/* Background Thumbnail preview */}
            <img
              src={course.thumbnail}
              alt={course.title}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
                isPlaying ? 'opacity-40 filter blur-xs' : 'opacity-70'
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/60" />

            {/* Top Bar inside Video */}
            <div className="relative z-10 flex items-center justify-between text-white text-xs">
              <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md font-mono">
                {course.instructor.name}
              </span>
              <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md font-mono">
                Thời lượng: {lesson.durationMinutes} phút
              </span>
            </div>

            {/* Center Play/Pause Button */}
            <div className="relative z-10 flex items-center justify-center">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-16 h-16 rounded-full bg-[#3E4C82]/90 hover:bg-[#3E4C82] text-white flex items-center justify-center shadow-xl transition-transform hover:scale-110 active:scale-95 border border-white/20"
                aria-label={isPlaying ? 'Tạm dừng video' : 'Phát video'}
              >
                {isPlaying ? <Pause size={28} /> : <Play size={28} className="ml-1" />}
              </button>
            </div>

            {/* Bottom Controls Bar */}
            <div className="relative z-10 space-y-2 text-white">
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={videoProgress}
                  onChange={(e) => setVideoProgress(Number(e.target.value))}
                  className="flex-1 accent-[#E2A33D] h-1.5 bg-white/30 rounded-lg cursor-pointer"
                />
                <span className="text-[11px] font-mono text-slate-300">
                  {Math.floor((videoProgress / 100) * lesson.durationMinutes)}:{((videoProgress % 60)).toString().padStart(2, '0')} / {lesson.durationMinutes}:00
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-white/10 text-[11px] font-mono">HD 1080p</span>
                  <span className="px-2 py-0.5 rounded bg-white/10 text-[11px] font-mono">Tốc độ: 1.0x</span>
                </div>
                <span className="text-[11px] text-[#E2A33D] font-semibold">
                  {isPlaying ? '▶ Đang phát video bài giảng' : '⏸ Đã tạm dừng'}
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-[#E2E0D8] dark:border-[#2D3349] pb-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab('content')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'content'
                  ? 'bg-[#3E4C82] text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <BookOpen size={16} />
              <span>Nội dung bài học</span>
            </button>

            <button
              onClick={() => setActiveTab('takeaways')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'takeaways'
                  ? 'bg-[#3E4C82] text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Award size={16} />
              <span>Ghi chú & Trọng tâm ({lesson.keyTakeaways?.length || 0})</span>
            </button>

            {lesson.practiceQuestions && lesson.practiceQuestions.length > 0 && (
              <button
                onClick={() => setActiveTab('quiz')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  activeTab === 'quiz'
                    ? 'bg-[#3E4C82] text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <HelpCircle size={16} />
                <span>Trắc nghiệm nhanh ({lesson.practiceQuestions.length})</span>
              </button>
            )}
          </div>

          {/* Tab Content Display */}
          <div className="bg-slate-50 dark:bg-slate-900/50 p-4 sm:p-6 rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349]">
            {activeTab === 'content' && (
              <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                {lesson.content}
              </div>
            )}

            {activeTab === 'takeaways' && (
              <div className="space-y-3">
                <h4 className="font-bold font-heading text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Award size={18} className="text-[#E2A33D]" />
                  Các điểm cốt lõi cần ghi nhớ:
                </h4>
                <ul className="space-y-2">
                  {lesson.keyTakeaways?.map((item, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-2.5 p-3 rounded-xl bg-white dark:bg-[#1C1F2E] border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-300"
                    >
                      <CheckCircle2 size={16} className="text-[#6E9E72] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === 'quiz' && lesson.practiceQuestions && (
              <div className="space-y-4">
                {lesson.practiceQuestions.map((q, qIndex) => {
                  const isCorrect = selectedQuizOption === q.correctIndex;
                  return (
                    <div key={qIndex} className="space-y-3">
                      <p className="font-bold text-sm text-slate-900 dark:text-white">
                        Câu hỏi: {q.question}
                      </p>

                      <div className="space-y-2">
                        {q.options.map((opt, optIndex) => {
                          let optClasses = 'border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1C1F2E] text-slate-800 dark:text-slate-200 hover:border-[#3E4C82]';
                          if (selectedQuizOption === optIndex) {
                            optClasses = 'border-[#3E4C82] bg-[#3E4C82]/10 text-[#3E4C82] dark:text-white font-semibold ring-2 ring-[#3E4C82]/20';
                          }
                          if (quizSubmitted) {
                            if (optIndex === q.correctIndex) {
                              optClasses = 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-bold';
                            } else if (selectedQuizOption === optIndex && !isCorrect) {
                              optClasses = 'border-rose-500 bg-rose-500/10 text-rose-700 dark:text-rose-300 line-through';
                            }
                          }

                          return (
                            <button
                              key={optIndex}
                              onClick={() => handleQuizSelect(optIndex)}
                              className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between ${optClasses}`}
                            >
                              <span>{String.fromCharCode(65 + optIndex)}. {opt}</span>
                            </button>
                          );
                        })}
                      </div>

                      {/* Submit / Result */}
                      {!quizSubmitted ? (
                        <button
                          disabled={selectedQuizOption === null}
                          onClick={() => setQuizSubmitted(true)}
                          className="mt-3 px-5 py-2 rounded-xl bg-[#3E4C82] text-white text-xs sm:text-sm font-bold hover:bg-[#323D6B] disabled:opacity-40 transition-colors"
                        >
                          Kiểm tra đáp án
                        </button>
                      ) : (
                        <div className={`p-4 rounded-xl text-xs sm:text-sm leading-relaxed border ${
                          isCorrect
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300'
                            : 'bg-amber-500/10 border-amber-500/30 text-amber-800 dark:text-amber-300'
                        }`}>
                          <p className="font-bold mb-1">
                            {isCorrect ? '✅ Chính xác!' : '❌ Chưa chính xác!'}
                          </p>
                          <p>{q.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 bg-white dark:bg-[#1C1F2E] border-t border-[#E2E0D8] dark:border-[#2D3349] flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              disabled={!prevLesson}
              onClick={() => {
                if (prevLesson) {
                  setActiveLesson({ course, lesson: prevLesson });
                  setQuizSubmitted(false);
                  setSelectedQuizOption(null);
                }
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs sm:text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
            >
              <ChevronLeft size={16} />
              <span>Bài trước</span>
            </button>

            <button
              disabled={!nextLesson}
              onClick={() => {
                if (nextLesson) {
                  setActiveLesson({ course, lesson: nextLesson });
                  setQuizSubmitted(false);
                  setSelectedQuizOption(null);
                }
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs sm:text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
            >
              <span>Bài tiếp theo</span>
              <ChevronRight size={16} />
            </button>
          </div>

          <button
            onClick={handleMarkComplete}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#6E9E72] hover:bg-[#5C8960] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#6E9E72]/20 transition-all active:scale-95"
          >
            <CheckCircle2 size={18} />
            <span>Đánh dấu hoàn thành (+25 điểm)</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
