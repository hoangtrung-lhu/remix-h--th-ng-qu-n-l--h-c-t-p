import React from 'react';
import { useApp } from '@/context/AppContext';
import { navigation } from '@/data/mockData';
import {
  GraduationCap,
  Flame,
  LogOut,
  X,
  Sparkles,
  Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Sidebar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    mobileMenuOpen,
    setMobileMenuOpen,
    user,
    tasks,
    unreadNotificationCount,
    logout,
    setIsAIAssistantOpen
  } = useApp();

  const pendingTasksCount = tasks.filter(t => t.status !== 'completed').length;

  const NavContent = (
    <div className="flex flex-col h-full bg-[#262F52] text-slate-300 select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-5 border-b border-slate-700/50">
        <div
          onClick={() => {
            setCurrentView('dashboard');
            setMobileMenuOpen(false);
          }}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#E2A33D] to-[#3E4C82] flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
            <GraduationCap size={22} className="text-white" />
          </div>
          <div>
            <span className="font-bold text-lg font-heading text-white tracking-tight flex items-center gap-1">
              Edu<span className="text-[#E2A33D]">LMS</span>
            </span>
            <span className="text-[10px] text-slate-400 block -mt-1 tracking-wider uppercase">
              Học tập thông minh
            </span>
          </div>
        </div>

        {/* Mobile close button */}
        <button
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50"
          aria-label="Đóng menu"
        >
          <X size={20} />
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 py-5 px-3 space-y-1.5 overflow-y-auto">
        <div className="px-3 mb-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-heading">
          Menu Chính
        </div>

        {navigation.map((item) => {
          const isActive = currentView === item.id;
          let badgeCount: number | null = null;
          if (item.id === 'tasks' && pendingTasksCount > 0) {
            badgeCount = pendingTasksCount;
          } else if (item.id === 'notifications' && unreadNotificationCount > 0) {
            badgeCount = unreadNotificationCount;
          }

          return (
            <button
              key={item.id}
              onClick={() => {
                setCurrentView(item.id);
                setMobileMenuOpen(false);
              }}
              className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all duration-200 text-sm font-medium w-full text-left group ${
                isActive
                  ? 'bg-white/10 text-white font-semibold shadow-sm backdrop-blur-sm'
                  : 'text-slate-300 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <item.icon
                  size={19}
                  className={`transition-colors ${
                    isActive ? 'text-[#E2A33D]' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <span>{item.name}</span>
              </div>

              {badgeCount !== null && (
                <span
                  className={`px-2 py-0.5 text-[11px] font-bold font-mono rounded-full ${
                    item.id === 'tasks'
                      ? 'bg-[#E2A33D] text-slate-950'
                      : 'bg-[#C56464] text-white'
                  }`}
                >
                  {badgeCount}
                </span>
              )}
            </button>
          );
        })}

        {/* AI Assistant Banner Card in Sidebar */}
        <div className="pt-4 px-1">
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-[#7C6FE3]/25 to-[#3E4C82]/30 border border-[#7C6FE3]/30 text-white relative overflow-hidden">
            <div className="flex items-center gap-2 mb-1.5">
              <Sparkles size={16} className="text-[#7C6FE3] animate-pulse" />
              <span className="text-xs font-bold font-heading">Trợ lý AI Tutor</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed mb-3">
              Hỏi đáp công thức, tóm tắt bài tập và lập kế hoạch ôn thi ngay.
            </p>
            <button
              onClick={() => {
                setIsAIAssistantOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full py-1.5 px-3 bg-[#7C6FE3] hover:bg-[#6A5CD6] text-white text-xs font-bold rounded-lg transition-colors shadow-sm flex items-center justify-center gap-1.5"
            >
              <Sparkles size={13} />
              Mở Trợ lý AI
            </button>
          </div>
        </div>
      </nav>

      {/* Streak and Points Box */}
      <div className="p-3 border-t border-slate-700/50">
        <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#E2A33D]/20 text-[#E2A33D] flex items-center justify-center">
              <Flame size={18} className="animate-bounce" />
            </div>
            <div>
              <p className="text-[11px] text-slate-400 font-medium">Chuỗi học tập</p>
              <p className="text-xs font-bold text-white font-mono">{user.streakDays} ngày liên tiếp</p>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1 text-[#E2A33D] text-xs font-bold font-mono">
              <Award size={13} />
              <span>{user.points} pts</span>
            </div>
          </div>
        </div>

        {/* User preview & Logout */}
        <div className="flex items-center justify-between pt-1">
          <div
            onClick={() => {
              setCurrentView('profile');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <img
              src={user.avatar}
              alt={user.name}
              className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-600"
            />
            <div className="min-w-0 max-w-[110px]">
              <p className="text-xs font-bold text-white truncate">{user.name}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
            </div>
          </div>

          <button
            onClick={logout}
            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
            title="Đăng xuất"
            aria-label="Đăng xuất"
          >
            <LogOut size={17} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar (Fixed) */}
      <aside className="hidden lg:block w-64 shrink-0 h-screen sticky top-0 z-20 border-r border-slate-700/50 shadow-md">
        {NavContent}
      </aside>

      {/* Mobile Drawer (Slide-over) */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10"
            >
              {NavContent}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
