import React from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, AlertCircle, Info, X, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  return (
    <div className="fixed top-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          let Icon = CheckCircle2;
          let colorClasses = 'border-emerald-500/30 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 shadow-lg';
          let iconColor = 'text-emerald-500';

          if (toast.type === 'error') {
            Icon = AlertCircle;
            colorClasses = 'border-rose-500/30 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 shadow-lg';
            iconColor = 'text-rose-500';
          } else if (toast.type === 'warning') {
            Icon = AlertTriangle;
            colorClasses = 'border-amber-500/30 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 shadow-lg';
            iconColor = 'text-amber-500';
          } else if (toast.type === 'info') {
            Icon = Info;
            colorClasses = 'border-indigo-500/30 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 shadow-lg';
            iconColor = 'text-indigo-500';
          }

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.9 }}
              transition={{ duration: 0.2 }}
              className={`pointer-events-auto p-4 rounded-xl border flex items-start gap-3 relative overflow-hidden backdrop-blur-md ${colorClasses}`}
            >
              <div className="shrink-0 mt-0.5">
                <Icon size={20} className={iconColor} />
              </div>
              <div className="flex-1 min-w-0 pr-4">
                <h4 className="font-semibold text-sm leading-snug">{toast.title}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors p-1 rounded-md"
                aria-label="Đóng thông báo"
              >
                <X size={14} />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
