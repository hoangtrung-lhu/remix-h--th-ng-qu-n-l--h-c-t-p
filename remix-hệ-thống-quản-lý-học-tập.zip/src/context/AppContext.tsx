import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  Course,
  Task,
  ScheduleEvent,
  NotificationItem,
  AchievementBadge,
  ToastMessage,
  Lesson
} from '@/types';
import {
  initialUserProfile,
  initialCourses,
  catalogCourses,
  initialTasks,
  initialScheduleEvents,
  initialNotifications,
  initialBadges
} from '@/data/mockData';

interface AppContextType {
  // Theme & Layout
  darkMode: boolean;
  toggleDarkMode: () => void;
  currentView: string;
  setCurrentView: (view: string) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;

  // Auth state
  isAuthenticated: boolean;
  login: (email: string, pass: string) => boolean;
  register: (name: string, email: string, pass: string) => boolean;
  logout: () => void;

  // User Profile & Stats
  user: UserProfile;
  updateUserProfile: (updated: Partial<UserProfile>) => void;
  badges: AchievementBadge[];

  // Courses
  courses: Course[];
  catalogList: Course[];
  enrollCourse: (courseId: string) => void;
  updateLessonStatus: (courseId: string, lessonId: string, status: 'completed' | 'in_progress' | 'not_started') => void;
  selectedCourse: Course | null;
  setSelectedCourse: (course: Course | null) => void;
  activeLesson: { course: Course; lesson: Lesson } | null;
  setActiveLesson: (data: { course: Course; lesson: Lesson } | null) => void;

  // Tasks / Kanban
  tasks: Task[];
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTaskStatus: (taskId: string, status: 'todo' | 'in_progress' | 'completed') => void;
  updateTask: (task: Task) => void;
  deleteTask: (taskId: string) => void;

  // Schedule
  scheduleEvents: ScheduleEvent[];
  addScheduleEvent: (event: Omit<ScheduleEvent, 'id'>) => void;
  updateScheduleEvent: (event: ScheduleEvent) => void;
  deleteScheduleEvent: (eventId: string) => void;

  // Notifications
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'timeAgo' | 'date'>) => void;

  // Modals
  isNewTaskModalOpen: boolean;
  setIsNewTaskModalOpen: (open: boolean) => void;
  isNewEventModalOpen: boolean;
  setIsNewEventModalOpen: (open: boolean) => void;
  isEnrollModalOpen: boolean;
  setIsEnrollModalOpen: (open: boolean) => void;
  isAIAssistantOpen: boolean;
  setIsAIAssistantOpen: (open: boolean) => void;

  // Toasts
  toasts: ToastMessage[];
  showToast: (type: 'success' | 'info' | 'warning' | 'error', title: string, message: string) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  THEME: 'edulms_theme_dark',
  USER: 'edulms_user_profile',
  AUTH: 'edulms_is_auth',
  COURSES: 'edulms_courses',
  TASKS: 'edulms_tasks',
  SCHEDULE: 'edulms_schedule',
  NOTIFICATIONS: 'edulms_notifications',
  BADGES: 'edulms_badges',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return saved ? JSON.parse(saved) : false;
  });

  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUTH);
    return saved ? JSON.parse(saved) : true;
  });

  // User Profile
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    return saved ? JSON.parse(saved) : initialUserProfile;
  });

  // Badges
  const [badges, setBadges] = useState<AchievementBadge[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BADGES);
    return saved ? JSON.parse(saved) : initialBadges;
  });

  // Courses
  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
    return saved ? JSON.parse(saved) : initialCourses;
  });

  const [catalogList] = useState<Course[]>(catalogCourses);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [activeLesson, setActiveLesson] = useState<{ course: Course; lesson: Lesson } | null>(null);

  // Tasks
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
    return saved ? JSON.parse(saved) : initialTasks;
  });

  // Schedule
  const [scheduleEvents, setScheduleEvents] = useState<ScheduleEvent[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SCHEDULE);
    return saved ? JSON.parse(saved) : initialScheduleEvents;
  });

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return saved ? JSON.parse(saved) : initialNotifications;
  });

  // Modals
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [isNewEventModalOpen, setIsNewEventModalOpen] = useState(false);
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Apply dark mode to document element
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.THEME, JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SCHEDULE, JSON.stringify(scheduleEvents));
  }, [scheduleEvents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(badges));
  }, [badges]);

  const toggleDarkMode = () => {
    setDarkMode(prev => !prev);
  };

  const showToast = (type: 'success' | 'info' | 'warning' | 'error', title: string, message: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const login = (email: string, _pass: string) => {
    setIsAuthenticated(true);
    setUser(prev => ({ ...prev, email: email || prev.email }));
    showToast('success', 'Đăng nhập thành công', `Chào mừng ${user.name} đã quay trở lại!`);
    return true;
  };

  const register = (name: string, email: string, _pass: string) => {
    setIsAuthenticated(true);
    setUser(prev => ({ ...prev, name: name || 'Học viên mới', email: email || 'user@example.com' }));
    showToast('success', 'Đăng ký tài khoản thành công', 'Chào mừng bạn đến với hệ thống học tập EduLMS!');
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    showToast('info', 'Đã đăng xuất', 'Bạn đã đăng xuất khỏi hệ thống EduLMS.');
  };

  const updateUserProfile = (updated: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updated }));
    showToast('success', 'Cập nhật thành công', 'Thông tin cá nhân đã được lưu.');
  };

  const enrollCourse = (courseId: string) => {
    const existing = courses.find(c => c.id === courseId);
    if (existing) {
      showToast('info', 'Thông báo', 'Bạn đã đăng ký khóa học này rồi!');
      return;
    }
    const target = catalogList.find(c => c.id === courseId);
    if (target) {
      const newCourse: Course = {
        ...target,
        isEnrolled: true,
        enrolledDate: new Date().toLocaleDateString('vi-VN'),
        progress: 0,
        completedLessons: 0
      };
      setCourses(prev => [newCourse, ...prev]);
      showToast('success', 'Đăng ký thành công', `Bạn đã ghi danh vào khóa "${newCourse.title}"!`);
      
      // Auto add notification
      addNotification({
        title: 'Đăng ký khóa học mới',
        message: `Bạn vừa ghi danh vào khóa "${newCourse.title}". Hãy bắt đầu bài học đầu tiên nhé!`,
        read: false,
        type: 'system',
        actionView: 'courses',
        relatedId: newCourse.id
      });
    }
  };

  const updateLessonStatus = (
    courseId: string,
    lessonId: string,
    status: 'completed' | 'in_progress' | 'not_started'
  ) => {
    setCourses(prev =>
      prev.map(course => {
        if (course.id !== courseId) return course;

        let completedCount = 0;
        let totalCount = 0;

        const updatedChapters = course.chapters.map(chapter => {
          const updatedLessons = chapter.lessons.map(lesson => {
            totalCount++;
            if (lesson.id === lessonId) {
              const newStatus = status;
              if (newStatus === 'completed') completedCount++;
              return { ...lesson, status: newStatus };
            } else {
              if (lesson.status === 'completed') completedCount++;
              return lesson;
            }
          });
          return { ...chapter, lessons: updatedLessons };
        });

        const newProgress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

        // Check if selected course is open and update it
        if (selectedCourse?.id === courseId) {
          setSelectedCourse(prev => prev ? {
            ...prev,
            chapters: updatedChapters,
            progress: newProgress,
            completedLessons: completedCount
          } : null);
        }

        return {
          ...course,
          chapters: updatedChapters,
          progress: newProgress,
          completedLessons: completedCount,
          lastAccessed: 'Vừa xong'
        };
      })
    );

    if (status === 'completed') {
      showToast('success', 'Hoàn thành bài học! 🎯', 'Tiến độ khóa học của bạn đã được cập nhật.');
      // Add points
      setUser(prev => ({ ...prev, points: prev.points + 25 }));
    }
  };

  const addTask = (taskData: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...taskData,
      id: 'task_' + Date.now()
    };
    setTasks(prev => [newTask, ...prev]);
    showToast('success', 'Thêm nhiệm vụ thành công', `Đã tạo nhiệm vụ: "${newTask.title}"`);
  };

  const updateTaskStatus = (taskId: string, status: 'todo' | 'in_progress' | 'completed') => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === taskId) {
          const isFinished = status === 'completed';
          return {
            ...t,
            status,
            completedAt: isFinished ? new Date().toLocaleString('vi-VN') : undefined
          };
        }
        return t;
      })
    );

    if (status === 'completed') {
      showToast('success', 'Xuất sắc! 🎉', 'Bạn đã hoàn thành bài tập này.');
      setUser(prev => ({ ...prev, points: prev.points + 30 }));
    } else {
      showToast('info', 'Cập nhật trạng thái', 'Đã chuyển trạng thái nhiệm vụ.');
    }
  };

  const updateTask = (updatedTask: Task) => {
    setTasks(prev => prev.map(t => (t.id === updatedTask.id ? updatedTask : t)));
    showToast('success', 'Lưu thay đổi', 'Đã cập nhật chi tiết nhiệm vụ.');
  };

  const deleteTask = (taskId: string) => {
    const target = tasks.find(t => t.id === taskId);
    setTasks(prev => prev.filter(t => t.id !== taskId));
    showToast('info', 'Đã xóa nhiệm vụ', `Đã xóa "${target?.title || 'bài tập'}"`);
  };

  const addScheduleEvent = (eventData: Omit<ScheduleEvent, 'id'>) => {
    const newEvent: ScheduleEvent = {
      ...eventData,
      id: 'evt_' + Date.now()
    };
    setScheduleEvents(prev => [...prev, newEvent]);
    showToast('success', 'Thêm lịch học thành công', `Đã lên lịch cho sự kiện: "${newEvent.title}"`);
  };

  const updateScheduleEvent = (eventData: ScheduleEvent) => {
    setScheduleEvents(prev => prev.map(e => (e.id === eventData.id ? eventData : e)));
    showToast('success', 'Cập nhật lịch học', 'Đã lưu thay đổi sự kiện.');
  };

  const deleteScheduleEvent = (eventId: string) => {
    const target = scheduleEvents.find(e => e.id === eventId);
    setScheduleEvents(prev => prev.filter(e => e.id !== eventId));
    showToast('info', 'Đã hủy sự kiện', `Đã xóa lịch: "${target?.title || 'sự kiện'}"`);
  };

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('info', 'Thông báo', 'Đã đánh dấu tất cả là đã đọc.');
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'timeAgo' | 'date'>) => {
    const newNotif: NotificationItem = {
      ...notif,
      id: 'notif_' + Date.now(),
      timeAgo: 'Vừa xong',
      date: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        darkMode,
        toggleDarkMode,
        currentView,
        setCurrentView,
        mobileMenuOpen,
        setMobileMenuOpen,
        isAuthenticated,
        login,
        register,
        logout,
        user,
        updateUserProfile,
        badges,
        courses,
        catalogList,
        enrollCourse,
        updateLessonStatus,
        selectedCourse,
        setSelectedCourse,
        activeLesson,
        setActiveLesson,
        tasks,
        addTask,
        updateTaskStatus,
        updateTask,
        deleteTask,
        scheduleEvents,
        addScheduleEvent,
        updateScheduleEvent,
        deleteScheduleEvent,
        notifications,
        unreadNotificationCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addNotification,
        isNewTaskModalOpen,
        setIsNewTaskModalOpen,
        isNewEventModalOpen,
        setIsNewEventModalOpen,
        isEnrollModalOpen,
        setIsEnrollModalOpen,
        isAIAssistantOpen,
        setIsAIAssistantOpen,
        toasts,
        showToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
