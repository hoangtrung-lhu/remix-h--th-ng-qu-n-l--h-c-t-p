import {
  BookOpen,
  Calendar,
  Bell,
  Settings,
  LayoutDashboard,
  CheckSquare,
  User,
} from 'lucide-react';
import {
  Course,
  Task,
  ScheduleEvent,
  NotificationItem,
  AchievementBadge,
  UserProfile
} from '@/types';

export const navigation = [
  { name: 'Tổng quan', id: 'dashboard', icon: LayoutDashboard },
  { name: 'Khóa học', id: 'courses', icon: BookOpen },
  { name: 'Nhiệm vụ & Bài tập', id: 'tasks', icon: CheckSquare },
  { name: 'Lịch học', id: 'schedule', icon: Calendar },
  { name: 'Thông báo', id: 'notifications', icon: Bell },
  { name: 'Hồ sơ & Thành tích', id: 'profile', icon: User },
  { name: 'Cài đặt', id: 'settings', icon: Settings },
];

export const initialUserProfile: UserProfile = {
  id: 'user_01',
  name: 'Nguyễn Minh Quân',
  email: 'minhquan.edu@gmail.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop',
  school: 'THPT Chuyên Hà Nội - Amsterdam',
  grade: 'Lớp 12 Chuyên Toán',
  bio: 'Mục tiêu: Đạt 28+ điểm thi tốt nghiệp THPT và IELTS 7.5. Luôn nỗ lực học tập mỗi ngày!',
  targetHoursPerWeek: 20,
  streakDays: 7,
  points: 1250,
  joinedDate: 'Tháng 1, 2026',
  notificationPreferences: {
    assignments: true,
    schedule: true,
    achievements: true,
    news: false,
  }
};

export const initialCourses: Course[] = [
  {
    id: 'course_toan_12',
    code: 'MATH12-PRO',
    title: 'Toán Học 12: Chinh Phục Hàm Số & Hình Không Gian',
    subject: 'Toán học',
    instructor: {
      name: 'ThS. Lê Thành Nam',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
      title: 'Giảng viên Chuyên Toán Đại học Sư Phạm'
    },
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=800&auto=format&fit=crop',
    progress: 75,
    totalLessons: 24,
    completedLessons: 18,
    description: 'Khóa học toàn diện bao gồm chuyên đề Khảo sát hàm số, Tích phân & Ứng dụng, Tọa độ không gian Oxyz và Hình học không gian đa diện.',
    targetAudience: 'Học sinh lớp 12 luyện thi THPT Quốc gia',
    rating: 4.9,
    reviewCount: 328,
    durationHours: 36,
    enrolledDate: '15/05/2026',
    lastAccessed: '2 giờ trước',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_math_1',
        title: 'Chương 1: Ứng dụng đạo hàm để khảo sát hàm số',
        lessons: [
          {
            id: 'les_math_1',
            title: '1. Tính đơn điệu của hàm số và cực trị',
            durationMinutes: 45,
            type: 'video',
            status: 'completed',
            videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            content: `### 1. Định lý tính đơn điệu
Cho hàm số $y = f(x)$ có đạo hàm trên khoảng $K$:
- Nếu $f'(x) > 0, \\forall x \\in K$ thì hàm số đồng biến trên $K$.
- Nếu $f'(x) < 0, \\forall x \\in K$ thì hàm số nghịch biến trên $K$.
- Nếu $f'(x) = 0, \\forall x \\in K$ thì hàm số là hằng số trên $K$.

### 2. Quy tắc tìm cực trị
1. Tìm tập xác định $D$.
2. Tính $f'(x)$, tìm các điểm tới hạn $x_i$ mà tại đó $f'(x_i) = 0$ hoặc đạo hàm không xác định.
3. Lập bảng xét dấu đạo hàm và kết luận.`,
            keyTakeaways: [
              'Nắm chắc bảng xét dấu đạo hàm bậc 2 và bậc 3.',
              'Nhớ quy tắc xét nghiệm bội chẵn không làm đổi dấu đạo hàm.',
              'Lưu ý điều kiện đủ để hàm số đạt cực trị tại x0.'
            ],
            practiceQuestions: [
              {
                question: 'Hàm số y = x^3 - 3x + 2 đồng biến trên khoảng nào dưới đây?',
                options: ['(-1; 1)', '(-∞; -1) và (1; +∞)', '(0; +∞)', '(-∞; 0)'],
                correctIndex: 1,
                explanation: 'Đạo hàm y\' = 3x^2 - 3 = 3(x-1)(x+1). Ta có y\' > 0 khi x > 1 hoặc x < -1. Vậy hàm số đồng biến trên (-∞; -1) và (1; +∞).'
              }
            ]
          },
          {
            id: 'les_math_2',
            title: '2. Giá trị lớn nhất và nhỏ nhất của hàm số',
            durationMinutes: 40,
            type: 'video',
            status: 'completed',
            content: `### Phương pháp tìm GTLN - GTNN trên đoạn [a; b]
1. Tính $f'(x)$ và giải phương trình $f'(x) = 0$ tìm các nghiệm $x_1, x_2, ... \\in [a; b]$.
2. Tính các giá trị $f(a), f(b), f(x_1), f(x_2)...$.
3. Số lớn nhất trong các giá trị trên là $\\max f(x)$, số bé nhất là $\\min f(x)$.`,
            keyTakeaways: [
              'Chỉ nhận nghiệm thuộc đoạn [a; b].',
              'Nếu tìm trên khoảng (a; b) bắt buộc phải lập bảng biến thiên.'
            ]
          },
          {
            id: 'les_math_3',
            title: '3. Đường tiệm cận của đồ thị hàm số',
            durationMinutes: 35,
            type: 'reading',
            status: 'completed',
            content: `### Các loại đường tiệm cận
- **Tiệm cận đứng:** Đường thẳng $x = x_0$ là TCĐ nếu ít nhất một trong các giới hạn $\\lim_{x \\to x_0^+} f(x) = \\pm\\infty$ hoặc $\\lim_{x \\to x_0^-} f(x) = \\pm\\infty$.
- **Tiệm cận ngang:** Đường thẳng $y = y_0$ là TCN nếu $\\lim_{x \\to +\\infty} f(x) = y_0$ hoặc $\\lim_{x \\to -\\infty} f(x) = y_0$.`,
            keyTakeaways: [
              'Hàm phân thức bậc nhất trên bậc nhất y=(ax+b)/(cx+d) luôn có 1 TCĐ x=-d/c và 1 TCN y=a/c.'
            ]
          },
          {
            id: 'les_math_4',
            title: '4. Khảo sát và vẽ đồ thị các hàm số thường gặp',
            durationMinutes: 50,
            type: 'video',
            status: 'in_progress',
            content: `### Sơ đồ khảo sát hàm số
1. Tìm tập xác định.
2. Xét sự biến thiên (đạo hàm, cực trị, giới hạn, tiệm cận, bảng biến thiên).
3. Vẽ đồ thị (tìm giao điểm với các trục tọa độ, tâm đối xứng, trục đối xứng).`,
            keyTakeaways: [
              'Phân biệt đồ thị hàm bậc 3, hàm trùng phương bậc 4 và hàm nhất biến.',
              'Nhận diện các hệ số a, b, c, d từ hình dáng đồ thị cho trước.'
            ]
          }
        ]
      },
      {
        id: 'ch_math_2',
        title: 'Chương 2: Hình học không gian Oxyz',
        lessons: [
          {
            id: 'les_math_5',
            title: '5. Tọa độ của điểm và vecto trong không gian',
            durationMinutes: 45,
            type: 'video',
            status: 'not_started',
            content: 'Nắm vững các phép toán vecto, tích vô hướng, tích có hướng và ứng dụng tính diện tích, thể tích tứ diện trong Oxyz.',
            keyTakeaways: ['Tích có hướng của 2 vecto tạo ra vecto vuông góc với cả 2.']
          },
          {
            id: 'les_math_6',
            title: '6. Phương trình mặt phẳng và mặt cầu',
            durationMinutes: 55,
            type: 'video',
            status: 'not_started',
            content: 'Viết phương trình mặt phẳng đi qua 1 điểm và có vecto pháp tuyến; phương trình mặt cầu tâm I bán kính R.',
            keyTakeaways: ['Phương trình mặt phẳng: A(x-x0) + B(y-y0) + C(z-z0) = 0.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_ly_12',
    code: 'PHYS12-PRO',
    title: 'Vật Lý 12: Điện Xoay Chiều & Dao Động Cơ',
    subject: 'Vật lý',
    instructor: {
      name: 'ThS. Hoàng Trọng Nghĩa',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop',
      title: 'Giáo viên Chuyên Vật Lý Lương Thế Vinh'
    },
    thumbnail: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?q=80&w=800&auto=format&fit=crop',
    progress: 60,
    totalLessons: 20,
    completedLessons: 12,
    description: 'Chinh phục trọn vẹn điểm 8+ Vật lý với phương pháp giản đồ vecto chuẩn hóa, giải nhanh mạch RLC không phân nhánh và sóng dừng.',
    targetAudience: 'Học sinh ôn thi THPT & Đánh giá năng lực ĐHQG',
    rating: 4.85,
    reviewCount: 215,
    durationHours: 30,
    enrolledDate: '20/05/2026',
    lastAccessed: 'Hôm qua',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_phys_1',
        title: 'Chương 1: Mạch điện xoay chiều RLC',
        lessons: [
          {
            id: 'les_phys_1',
            title: '1. Đại cương về dòng điện xoay chiều',
            durationMinutes: 40,
            type: 'video',
            status: 'completed',
            content: 'Phương trình dao động điện xoay chiều: $i = I_0 \\cos(\\omega t + \\varphi_i)$. Giá trị hiệu dụng $I = I_0 / \\sqrt{2}$.',
            keyTakeaways: ['Tần số f = ω / (2π)', 'Nhiệt lượng tỏa ra tuân theo định luật Jun-Lenxơ.']
          },
          {
            id: 'les_phys_2',
            title: '2. Phương pháp giản đồ vecto Bu-sơ',
            durationMinutes: 50,
            type: 'video',
            status: 'in_progress',
            content: 'Sử dụng giản đồ vecto buộc và vecto trượt để biểu diễn điện áp các phần tử $U_R, U_L, U_C$ trên cùng một trục dòng điện.',
            keyTakeaways: ['uR cùng pha với i', 'uL sớm pha π/2 so với i', 'uC trễ pha π/2 so với i.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_hoa_12',
    code: 'CHEM12-PRO',
    title: 'Hóa Học 12: Este - Lipit & Hợp Chất Chứa Nitơ',
    subject: 'Hóa học',
    instructor: {
      name: 'Cô Vũ Thị Mai',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop',
      title: 'Tác giả sách Luyện thi Hóa Học 12'
    },
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?q=80&w=800&auto=format&fit=crop',
    progress: 45,
    totalLessons: 18,
    completedLessons: 8,
    description: 'Phương pháp dồn chất, bảo toàn khối lượng và quy đổi peptit giải quyết bài toán Este đa chức nâng cao trong đề thi đại học.',
    targetAudience: 'Học sinh khối A00, B00, D07',
    rating: 4.92,
    reviewCount: 412,
    durationHours: 28,
    enrolledDate: '01/06/2026',
    lastAccessed: '3 ngày trước',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_chem_1',
        title: 'Chương 1: Este và Chất Béo',
        lessons: [
          {
            id: 'les_chem_1',
            title: '1. Khái niệm, danh pháp và đồng phân Este',
            durationMinutes: 45,
            type: 'video',
            status: 'completed',
            content: 'Công thức chung của Este no đơn chức mạch hở: $C_n H_{2n} O_2$ ($n \\ge 2$). Danh pháp: Tên gốc hiđrocacbon R\' + Tên gốc axit RCOO (đuôi at).',
            keyTakeaways: ['Este có nhiệt độ sôi thấp hơn axit và ancol cùng số C do không tạo liên kết hiđro liên phân tử.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_anh_12',
    code: 'ENG-IELTS-7',
    title: 'Tiếng Anh 12 & Chiến Lược Đạt IELTS 7.0+',
    subject: 'Tiếng Anh',
    instructor: {
      name: 'Thầy David Wilson & Cô Minh Trang',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
      title: 'Cựu giám khảo IELTS & Giảng viên ĐH Ngoại Thương'
    },
    thumbnail: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=800&auto=format&fit=crop',
    progress: 80,
    totalLessons: 25,
    completedLessons: 20,
    description: 'Nâng cấp từ vựng học thuật C1/C2, thành thạo kỹ năng Đọc hiểu Skimming/Scanning và phương pháp viết luận Task 2 ấn tượng.',
    targetAudience: 'Học sinh thi tốt nghiệp THPT & chứng chỉ quốc tế',
    rating: 4.95,
    reviewCount: 520,
    durationHours: 40,
    enrolledDate: '10/05/2026',
    lastAccessed: 'Hôm nay',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_eng_1',
        title: 'Chương 1: Reading Comprehension Mastery',
        lessons: [
          {
            id: 'les_eng_1',
            title: '1. True/False/Not Given Strategy',
            durationMinutes: 45,
            type: 'video',
            status: 'completed',
            content: 'Master the subtle difference between False (contradicts the text) and Not Given (information is missing or cannot be proven).',
            keyTakeaways: ['Always look for keywords and qualifying words like always, never, only, occasionally.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_van_12',
    code: 'LIT12-MASTER',
    title: 'Ngữ Văn 12: Bình Luận & Nghị Luận Văn Học Trọng Tâm',
    subject: 'Ngữ văn',
    instructor: {
      name: 'TS. Nguyễn Thị Bích Ngọc',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop',
      title: 'Chuyên gia luyện thi Ngữ Văn Quốc Gia'
    },
    thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?q=80&w=800&auto=format&fit=crop',
    progress: 30,
    totalLessons: 16,
    completedLessons: 5,
    description: 'Phân tích sâu sắc các tác phẩm: Vợ chồng A Phủ, Vợ nhặt, Người lái đò Sông Đà, Chiếc thuyền ngoài xa, Đất Nước và Rừng xà nu.',
    targetAudience: 'Học sinh lớp 12 hướng tới điểm 8.5+ Ngữ Văn',
    rating: 4.88,
    reviewCount: 190,
    durationHours: 24,
    enrolledDate: '12/06/2026',
    lastAccessed: '5 ngày trước',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_lit_1',
        title: 'Chương 1: Văn xuôi kháng chiến',
        lessons: [
          {
            id: 'les_lit_1',
            title: '1. Giá trị nhân đạo trong tác phẩm Vợ Nhặt - Kim Lân',
            durationMinutes: 50,
            type: 'reading',
            status: 'completed',
            content: 'Phân tích tâm trạng của các nhân vật: Tràng, người vợ nhặt, bà cụ Tứ trong buổi sáng sau đêm tân hôn giữa nạn đói 1945.',
            keyTakeaways: ['Tình người và khát vọng sống mãnh liệt của người nông dân nghèo trong hoàn cảnh ngặt nghèo.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_tin_12',
    code: 'CS-PYTHON-APP',
    title: 'Tin Học & Lập Trình Python Cơ Bản Cho Học Sinh',
    subject: 'Tin học',
    instructor: {
      name: 'Kỹ sư Phạm Hoàng Long',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop',
      title: 'Senior AI Engineer & Giảng viên tin học trẻ'
    },
    thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=800&auto=format&fit=crop',
    progress: 10,
    totalLessons: 20,
    completedLessons: 2,
    description: 'Nền tảng lập trình Python, cấu trúc dữ liệu mảng, chuỗi, tệp và ứng dụng giải các bài toán tin học học sinh giỏi.',
    targetAudience: 'Học sinh yêu thích công nghệ và lập trình',
    rating: 4.96,
    reviewCount: 310,
    durationHours: 32,
    enrolledDate: '01/07/2026',
    lastAccessed: '1 tuần trước',
    color: '#3E4C82',
    isEnrolled: true,
    chapters: [
      {
        id: 'ch_cs_1',
        title: 'Chương 1: Cú pháp cơ bản Python',
        lessons: [
          {
            id: 'les_cs_1',
            title: '1. Kiểu dữ liệu, biến và toán tử',
            durationMinutes: 40,
            type: 'video',
            status: 'completed',
            content: 'Cài đặt môi trường Python, hiểu về int, float, str, bool và các cấu trúc điều khiển if-else, for, while.',
            keyTakeaways: ['Quy tắc thụt đầu dòng (indentation) trong Python.']
          }
        ]
      }
    ]
  }
];

// Additional catalog courses available for enrollment
export const catalogCourses: Course[] = [
  {
    id: 'course_sinh_12',
    code: 'BIO12-PRO',
    title: 'Sinh Học 12: Di Truyền Học & Tiến Hóa Nâng Cao',
    subject: 'Sinh học',
    instructor: {
      name: 'Cô Trần Thúy Hằng',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200&auto=format&fit=crop',
      title: 'Tiến sĩ Sinh học Phân tử ĐH Quốc Gia'
    },
    thumbnail: 'https://images.unsplash.com/photo-1530497610245-94d3c16cda28?q=80&w=800&auto=format&fit=crop',
    progress: 0,
    totalLessons: 22,
    completedLessons: 0,
    description: 'Nắm chắc kiến thức quy luật di truyền Men-đen, tương tác gen, hoán vị gen và di truyền quần thể đạt điểm tuyệt đối khối B.',
    targetAudience: 'Học sinh luyện thi khối Y Dược và khối B00',
    rating: 4.89,
    reviewCount: 175,
    durationHours: 34,
    enrolledDate: '',
    lastAccessed: 'Chưa học',
    color: '#6E9E72',
    isEnrolled: false,
    chapters: [
      {
        id: 'ch_bio_1',
        title: 'Chương 1: Cơ chế di truyền và biến dị',
        lessons: [
          {
            id: 'les_bio_1',
            title: '1. Gen, mã di truyền và quá trình nhân đôi ADN',
            durationMinutes: 45,
            type: 'video',
            status: 'not_started',
            content: 'Tổng quan cấu trúc ADN, nguyên tắc bán bảo toàn và vai trò của các enzim trong quá trình sao chép.',
            keyTakeaways: ['Nguyên tắc bổ sung A-T, G-X.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_su_12',
    code: 'HIST12-CHUYEN',
    title: 'Lịch Sử Việt Nam & Thế Giới Hiện Đại (1945 - 2000)',
    subject: 'Lịch sử',
    instructor: {
      name: 'ThS. Đỗ Văn Hùng',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=200&auto=format&fit=crop',
      title: 'Tác giả sơ đồ tư duy Lịch Sử 12'
    },
    thumbnail: 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?q=80&w=800&auto=format&fit=crop',
    progress: 0,
    totalLessons: 18,
    completedLessons: 0,
    description: 'Hệ thống hóa toàn bộ các mốc sự kiện quan trọng trong kháng chiến chống Pháp và chống Mỹ bằng phương pháp sơ đồ tư duy dễ nhớ.',
    targetAudience: 'Học sinh khối C00, D14, C19',
    rating: 4.91,
    reviewCount: 140,
    durationHours: 26,
    enrolledDate: '',
    lastAccessed: 'Chưa học',
    color: '#E2A33D',
    isEnrolled: false,
    chapters: [
      {
        id: 'ch_hist_1',
        title: 'Chương 1: Cách mạng tháng Tám và nước VNDCCH',
        lessons: [
          {
            id: 'les_hist_1',
            title: '1. Hoàn cảnh lịch sử và diễn biến Tổng khởi nghĩa 1945',
            durationMinutes: 40,
            type: 'video',
            status: 'not_started',
            content: 'Nắm vững thời cơ ngàn năm có một khi phát xít Nhật đầu hàng Đồng minh không điều kiện.',
            keyTakeaways: ['Bài học kinh nghiệm về chớp thời cơ và xây dựng khối đại đoàn kết.']
          }
        ]
      }
    ]
  },
  {
    id: 'course_dgnl_12',
    code: 'DGNL-SUPER',
    title: 'Chiến Thuật Luyện Đề Đánh Giá Năng Lực ĐHQG TP.HCM & HN',
    subject: 'Tổng hợp',
    instructor: {
      name: 'Hội đồng Giảng viên Chuyên ĐGNL',
      avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=200&auto=format&fit=crop',
      title: 'Tổ hợp Chuyên gia Luyện Thi Quốc Gia'
    },
    thumbnail: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=800&auto=format&fit=crop',
    progress: 0,
    totalLessons: 30,
    completedLessons: 0,
    description: 'Giải quyết 120 câu hỏi tư duy định lượng, định tính, giải quyết vấn đề khoa học với ngân hàng 50 bộ đề thi thử độc quyền.',
    targetAudience: 'Thí sinh tham dự kỳ thi Đánh giá năng lực & Tư duy',
    rating: 4.97,
    reviewCount: 650,
    durationHours: 50,
    enrolledDate: '',
    lastAccessed: 'Chưa học',
    color: '#7C6FE3',
    isEnrolled: false,
    chapters: [
      {
        id: 'ch_dgnl_1',
        title: 'Chương 1: Tư duy định lượng và xử lý số liệu',
        lessons: [
          {
            id: 'les_dgnl_1',
            title: '1. Kỹ năng đọc hiểu biểu đồ và bảng số liệu thống kê',
            durationMinutes: 50,
            type: 'video',
            status: 'not_started',
            content: 'Mẹo phân tích nhanh xu hướng, tính tốc độ tăng trưởng và ước lượng kết quả trong 60 giây.',
            keyTakeaways: ['Tránh các bẫy đơn vị đo lường và tỷ lệ % chênh lệch.']
          }
        ]
      }
    ]
  }
];

export const initialTasks: Task[] = [
  {
    id: 'task_01',
    title: 'Giải đề thi thử THPT Quốc gia số 04 - Môn Toán',
    subject: 'Toán học',
    dueDate: '2026-08-21',
    dueTime: '23:59',
    priority: 'Cao',
    status: 'todo',
    description: 'Hoàn thành 50 câu trắc nghiệm trong 90 phút, đặc biệt tập trung phần Tích phân và Hình học Oxyz điểm 9+.',
    estimatedMinutes: 90,
    courseId: 'course_toan_12'
  },
  {
    id: 'task_02',
    title: 'Viết bài luận IELTS Writing Task 2 (Education & Technology)',
    subject: 'Tiếng Anh',
    dueDate: '2026-08-20',
    dueTime: '21:00',
    priority: 'Cao',
    status: 'todo',
    description: 'Bài viết tối thiểu 250 từ: "Some people think that computers will completely replace human teachers. To what extent do you agree?"',
    estimatedMinutes: 45,
    courseId: 'course_anh_12'
  },
  {
    id: 'task_03',
    title: 'Bài tập trắc nghiệm Este - Lipit: 30 câu vận dụng cao',
    subject: 'Hóa học',
    dueDate: '2026-08-22',
    dueTime: '22:00',
    priority: 'Trung bình',
    status: 'todo',
    description: 'Áp dụng phương pháp đồng đẳng hóa và bảo toàn nguyên tố O để giải nhanh bài toán hỗn hợp Este.',
    estimatedMinutes: 60,
    courseId: 'course_hoa_12'
  },
  {
    id: 'task_04',
    title: 'Lập sơ đồ tư duy Giản đồ vecto Mạch RLC nối tiếp',
    subject: 'Vật lý',
    dueDate: '2026-08-20',
    dueTime: '18:00',
    priority: 'Cao',
    status: 'in_progress',
    description: 'Vẽ sơ đồ tổng hợp công thức cộng điện áp tức thời và công suất tiêu thụ mạch điện xoay chiều.',
    estimatedMinutes: 40,
    courseId: 'course_ly_12'
  },
  {
    id: 'task_05',
    title: 'Luyện nghe IELTS Listening Section 3 & 4 (Cambridge 18)',
    subject: 'Tiếng Anh',
    dueDate: '2026-08-23',
    dueTime: '20:00',
    priority: 'Trung bình',
    status: 'in_progress',
    description: 'Nghe và chép chính tả 2 bài hội thoại học thuật, ghi chú lại từ vựng bị bẫy phát âm.',
    estimatedMinutes: 45,
    courseId: 'course_anh_12'
  },
  {
    id: 'task_06',
    title: 'Đọc & Lập dàn ý phân tích nhân vật Mị trong đêm tình mùa xuân',
    subject: 'Ngữ văn',
    dueDate: '2026-08-19',
    dueTime: '23:00',
    priority: 'Thấp',
    status: 'completed',
    description: 'Lập dàn ý chi tiết 3 phần: sự thức tỉnh tâm hồn, diễn biến hành động và ý nghĩa nhân đạo của Tô Hoài.',
    estimatedMinutes: 50,
    completedAt: '2026-08-19 16:30',
    courseId: 'course_van_12'
  },
  {
    id: 'task_07',
    title: 'Viết chương trình Python giải phương trình bậc 2',
    subject: 'Tin học',
    dueDate: '2026-08-18',
    dueTime: '21:00',
    priority: 'Thấp',
    status: 'completed',
    description: 'Xử lý đầy đủ các trường hợp delta > 0, delta = 0, delta < 0 và trường hợp hệ số a = 0.',
    estimatedMinutes: 30,
    completedAt: '2026-08-18 19:45',
    courseId: 'course_tin_12'
  }
];

export const initialScheduleEvents: ScheduleEvent[] = [
  {
    id: 'evt_01',
    title: 'Lớp Chuyên đề Toán: Cực trị hàm trị tuyệt đối',
    subject: 'Toán học',
    date: '2026-08-20',
    startTime: '08:30',
    endTime: '10:30',
    type: 'online',
    instructor: 'ThS. Lê Thành Nam',
    locationOrLink: 'https://meet.google.com/abc-math-xyz',
    note: 'Chuẩn bị trước phiếu bài tập số 12 và máy tính Casio fx-580VNX.',
    color: '#3E4C82',
    courseId: 'course_toan_12'
  },
  {
    id: 'evt_02',
    title: 'Thí nghiệm Vật lý: Khảo sát dao động con lắc lò xo',
    subject: 'Vật lý',
    date: '2026-08-20',
    startTime: '14:00',
    endTime: '16:00',
    type: 'offline',
    instructor: 'ThS. Hoàng Trọng Nghĩa',
    locationOrLink: 'Phòng Thí nghiệm Vật lý 302 - Nhà A',
    note: 'Mặc áo blouse trắng và mang theo sổ tay báo cáo kết quả thực hành.',
    color: '#3E4C82',
    courseId: 'course_ly_12'
  },
  {
    id: 'evt_03',
    title: 'Luyện Speaking IELTS 1-on-1: Topic Technology & Future',
    subject: 'Tiếng Anh',
    date: '2026-08-21',
    startTime: '19:30',
    endTime: '20:30',
    type: 'online',
    instructor: 'Mr. David Wilson',
    locationOrLink: 'https://zoom.us/j/ielts-speaking-room',
    note: 'Luyện tập trả lời Part 2 trong 2 phút với các collocations chủ đề AI.',
    color: '#7C6FE3',
    courseId: 'course_anh_12'
  },
  {
    id: 'evt_04',
    title: 'Tự học: Ôn tập Hóa hữu cơ Este & Peptit',
    subject: 'Hóa học',
    date: '2026-08-22',
    startTime: '15:00',
    endTime: '17:30',
    type: 'self_study',
    instructor: 'Cá nhân',
    locationOrLink: 'Thư viện Tự học',
    note: 'Mục tiêu giải xong 40 câu hỏi mức độ thông hiểu và vận dụng.',
    color: '#E2A33D',
    courseId: 'course_hoa_12'
  },
  {
    id: 'evt_05',
    title: 'Học trực tuyến: Nghị luận xã hội 200 chữ',
    subject: 'Ngữ văn',
    date: '2026-08-23',
    startTime: '09:00',
    endTime: '11:00',
    type: 'online',
    instructor: 'TS. Nguyễn Thị Bích Ngọc',
    locationOrLink: 'https://meet.google.com/van-hoc-online',
    note: 'Chữa bài viết về tư duy phản biện và tinh thần cống hiến của thế hệ trẻ.',
    color: '#6E9E72',
    courseId: 'course_van_12'
  }
];

export const initialNotifications: NotificationItem[] = [
  {
    id: 'notif_01',
    title: 'Nhắc nhở hạn chót bài tập!',
    message: 'Bài tập "Viết bài luận IELTS Writing Task 2" sẽ hết hạn nộp vào 21:00 hôm nay.',
    timeAgo: '15 phút trước',
    date: '2026-08-19 21:15',
    read: false,
    type: 'assignment',
    actionView: 'tasks',
    relatedId: 'task_02'
  },
  {
    id: 'notif_02',
    title: 'Lịch học sắp diễn ra',
    message: 'Lớp Chuyên đề Toán của ThS. Lê Thành Nam sẽ bắt đầu lúc 08:30 sáng mai trên Google Meet.',
    timeAgo: '2 giờ trước',
    date: '2026-08-19 19:30',
    read: false,
    type: 'schedule',
    actionView: 'schedule',
    relatedId: 'evt_01'
  },
  {
    id: 'notif_03',
    title: 'Mở khóa huy hiệu mới!',
    message: 'Chúc mừng bạn đã đạt huy hiệu "Chuỗi 7 Ngày Vàng" khi duy trì việc học liên tục!',
    timeAgo: 'Hôm qua',
    date: '2026-08-18 10:00',
    read: true,
    type: 'achievement',
    actionView: 'profile'
  },
  {
    id: 'notif_04',
    title: 'Khóa học mới đã được cập nhật',
    message: 'Giảng viên đã thêm 3 bài giảng mới vào khóa "Hóa Học 12: Este - Lipit".',
    timeAgo: '2 ngày trước',
    date: '2026-08-17 14:20',
    read: true,
    type: 'system',
    actionView: 'courses',
    relatedId: 'course_hoa_12'
  }
];

export const initialBadges: AchievementBadge[] = [
  {
    id: 'badge_01',
    title: 'Chuỗi 7 Ngày Vàng',
    description: 'Học tập chăm chỉ 7 ngày liên tiếp không ngắt quãng.',
    icon: 'Flame',
    unlocked: true,
    progress: 7,
    maxProgress: 7,
    unlockedAt: '18/08/2026',
    category: 'streak',
    points: 200
  },
  {
    id: 'badge_02',
    title: 'Chiến Thần Toán Học',
    description: 'Hoàn thành 15 bài học và giải trên 50 bài tập môn Toán.',
    icon: 'Award',
    unlocked: true,
    progress: 18,
    maxProgress: 15,
    unlockedAt: '12/08/2026',
    category: 'course',
    points: 350
  },
  {
    id: 'badge_03',
    title: 'Chuyên Gia Quản Lý Deadline',
    description: 'Hoàn thành 10 bài tập trước thời hạn chót ít nhất 2 giờ.',
    icon: 'Clock',
    unlocked: true,
    progress: 10,
    maxProgress: 10,
    unlockedAt: '15/08/2026',
    category: 'task',
    points: 250
  },
  {
    id: 'badge_04',
    title: 'Cú Đêm Chăm Chỉ',
    description: 'Tích lũy 10 giờ học tập trong khung giờ 21:00 - 24:00.',
    icon: 'Moon',
    unlocked: false,
    progress: 7.5,
    maxProgress: 10,
    category: 'streak',
    points: 300
  },
  {
    id: 'badge_05',
    title: 'Khám Phá Cùng Trợ Lý AI',
    description: 'Hỏi đáp và nhờ Trợ lý AI giải đáp thắc mắc 10 lần.',
    icon: 'Sparkles',
    unlocked: false,
    progress: 4,
    maxProgress: 10,
    category: 'ai',
    points: 150
  },
  {
    id: 'badge_06',
    title: 'Bậc Thầy Toàn Diện',
    description: 'Tham gia học đồng thời ít nhất 5 môn học khác nhau.',
    icon: 'GraduationCap',
    unlocked: true,
    progress: 6,
    maxProgress: 5,
    unlockedAt: '05/08/2026',
    category: 'course',
    points: 400
  }
];

export const weeklyStudyHours = [
  { day: 'T2', hours: 3.5, target: 3.0, date: '14/08' },
  { day: 'T3', hours: 4.2, target: 3.0, date: '15/08' },
  { day: 'T4', hours: 2.8, target: 3.0, date: '16/08' },
  { day: 'T5', hours: 4.5, target: 3.0, date: '17/08' },
  { day: 'T6', hours: 3.0, target: 3.0, date: '18/08' },
  { day: 'T7', hours: 5.5, target: 4.0, date: '19/08' },
  { day: 'CN', hours: 4.0, target: 4.0, date: '20/08' },
];

export const subjectPerformance = [
  { subject: 'Toán học', score: 9.2, fullMark: 10 },
  { subject: 'Tiếng Anh', score: 8.8, fullMark: 10 },
  { subject: 'Vật lý', score: 8.5, fullMark: 10 },
  { subject: 'Hóa học', score: 8.0, fullMark: 10 },
  { subject: 'Ngữ văn', score: 7.8, fullMark: 10 },
  { subject: 'Tin học', score: 9.5, fullMark: 10 },
];
