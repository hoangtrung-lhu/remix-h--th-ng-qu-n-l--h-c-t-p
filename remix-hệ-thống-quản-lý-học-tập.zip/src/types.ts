export type TaskPriority = 'Cao' | 'Trung bình' | 'Thấp' | 'high' | 'medium' | 'low';
export type TaskStatus = 'todo' | 'in_progress' | 'completed';

export interface Task {
  id: string;
  title: string;
  subject: string;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm
  priority: TaskPriority;
  status: TaskStatus;
  description?: string;
  estimatedMinutes?: number;
  completedAt?: string;
  courseId?: string;
}

export type LessonType = 'video' | 'reading' | 'exercise';
export type LessonStatus = 'not_started' | 'in_progress' | 'completed';

export interface Lesson {
  id: string;
  title: string;
  durationMinutes: number;
  type: LessonType;
  status: LessonStatus;
  videoUrl?: string;
  content: string;
  keyTakeaways?: string[];
  practiceQuestions?: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }[];
}

export interface CourseChapter {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Course {
  id: string;
  code: string;
  title: string;
  subject: string; // 'Toán học' | 'Vật lý' | 'Hóa học' | 'Tiếng Anh' | 'Ngữ văn' | 'Tin học' | etc.
  instructor: {
    name: string;
    avatar: string;
    title: string;
  };
  thumbnail: string;
  progress: number; // 0 - 100
  totalLessons: number;
  completedLessons: number;
  description: string;
  targetAudience: string;
  rating: number;
  reviewCount: number;
  durationHours: number;
  enrolledDate: string;
  lastAccessed: string;
  chapters: CourseChapter[];
  color: string;
  isEnrolled: boolean;
}

export type ScheduleEventType = 'online' | 'offline' | 'self_study' | 'exam';

export interface ScheduleEvent {
  id: string;
  title: string;
  subject: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  type: ScheduleEventType;
  instructor?: string;
  location?: string;
  locationOrLink?: string;
  note?: string;
  color?: string;
  courseId?: string;
}

export type NotificationType = 'assignment' | 'schedule' | 'achievement' | 'system';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timeAgo: string;
  date: string;
  read: boolean;
  type: NotificationType;
  actionView?: string;
  relatedId?: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
  unlockedAt?: string;
  category?: 'streak' | 'course' | 'task' | 'ai';
  points?: number;
  pointsReward?: number;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  school: string;
  grade: string;
  bio: string;
  phone?: string;
  targetScore?: string;
  targetHoursPerWeek: number;
  streakDays: number;
  points: number;
  joinedDate: string;
  notificationPreferences: {
    assignments: boolean;
    schedule: boolean;
    achievements: boolean;
    news: boolean;
  };
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestions?: string[];
  referencedData?: {
    type: 'task' | 'course' | 'schedule';
    id: string;
    title: string;
  }[];
}
