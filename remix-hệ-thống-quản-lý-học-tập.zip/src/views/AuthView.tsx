import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Flame,
  BookOpen
} from 'lucide-react';
import { motion } from 'motion/react';

export const AuthView: React.FC = () => {
  const { login, register } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('nguyen.duc.khoa@edulms.vn');
  const [password, setPassword] = useState('123456');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !email.includes('@')) {
      setError('Vui lòng nhập địa chỉ email hợp lệ');
      return;
    }
    if (!password || password.length < 6) {
      setError('Mật khẩu phải có tối thiểu 6 ký tự');
      return;
    }
    if (mode === 'register' && !name.trim()) {
      setError('Vui lòng nhập họ và tên của bạn');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      if (mode === 'login') {
        login(email, password);
      } else {
        register(name, email, password);
      }
      setLoading(false);
    }, 400);
  };

  const handleDemoLogin = () => {
    setLoading(true);
    setTimeout(() => {
      login('nguyen.duc.khoa@edulms.vn', '123456');
      setLoading(false);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#F5F4EF] dark:bg-[#14161F] text-slate-900 dark:text-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8 transition-colors duration-200">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Brand */}
        <div className="inline-flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#E2A33D] to-[#3E4C82] flex items-center justify-center shadow-lg">
            <GraduationCap size={28} className="text-white" />
          </div>
          <span className="font-bold text-2xl font-heading tracking-tight text-[#262F52] dark:text-white">
            Edu<span className="text-[#E2A33D]">LMS</span>
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white tracking-tight">
          {mode === 'login' ? 'Đăng Nhập Cổng Học Tập' : 'Đăng Ký Tài Khoản Học Viên'}
        </h2>
        <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          Hệ thống Quản lý Học tập Thông minh & Ôn thi THPT Quốc gia
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#1C1F2E] py-8 px-6 sm:px-10 shadow-xl rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] space-y-6"
        >
          {/* Toggle Tab */}
          <div className="flex p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl">
            <button
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                mode === 'login'
                  ? 'bg-white dark:bg-[#1C1F2E] text-[#3E4C82] dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Đăng Nhập
            </button>
            <button
              onClick={() => {
                setMode('register');
                setError('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                mode === 'register'
                  ? 'bg-white dark:bg-[#1C1F2E] text-[#3E4C82] dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Đăng Ký Mới
            </button>
          </div>

          {/* Quick Demo Login Button */}
          <button
            onClick={handleDemoLogin}
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-2xl bg-[#E2A33D]/10 hover:bg-[#E2A33D]/20 text-[#C88E32] dark:text-[#E2A33D] border border-[#E2A33D]/30 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Sparkles size={16} className="text-[#E2A33D]" />
            <span>Đăng nhập nhanh (Tài khoản học sinh mẫu)</span>
          </button>

          <div className="relative flex items-center justify-center">
            <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
            <span className="bg-white dark:bg-[#1C1F2E] px-3 text-[11px] font-mono text-slate-400 uppercase shrink-0">
              hoặc điền thông tin
            </span>
          </div>

          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2.5">
              <AlertCircle size={16} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Họ và tên học viên <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="VD: Nguyễn Đức Khoa"
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#3E4C82]"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Địa chỉ Email <span className="text-rose-500">*</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@example.com"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#3E4C82]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Mật khẩu <span className="text-rose-500">*</span>
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Tối thiểu 6 ký tự"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#3E4C82]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-2xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#3E4C82]/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              <span>{loading ? 'Đang xác thực...' : mode === 'login' ? 'Đăng Nhập Vào EduLMS' : 'Hoàn Tất Đăng Ký'}</span>
              <ArrowRight size={16} />
            </button>
          </form>

          {/* Features Highlights */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-[11px] text-slate-500 dark:text-slate-400">
            <p className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#6E9E72]" />
              <span>Học tập không giới hạn với hệ thống chuyên đề chuẩn</span>
            </p>
            <p className="flex items-center gap-2">
              <Sparkles size={14} className="text-[#7C6FE3]" />
              <span>Gia sư Trợ lý AI giải đáp thắc mắc 24/7</span>
            </p>
            <p className="flex items-center gap-2">
              <Flame size={14} className="text-[#E2A33D]" />
              <span>Tích điểm thưởng và giữ chuỗi học tập mỗi ngày</span>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
