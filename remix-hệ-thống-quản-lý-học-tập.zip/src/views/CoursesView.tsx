import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Search,
  Plus,
  BookOpen,
  Star,
  Play,
  Clock,
  CheckCircle2,
  Filter,
  Layers
} from 'lucide-react';
import { motion } from 'motion/react';

export const CoursesView: React.FC = () => {
  const {
    courses,
    setSelectedCourse,
    setActiveLesson,
    setIsEnrollModalOpen
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('Tất cả');
  const [filterProgress, setFilterProgress] = useState<'all' | 'in_progress' | 'completed'>('all');

  const subjects = ['Tất cả', 'Toán học', 'Vật lý', 'Hóa học', 'Tiếng Anh', 'Ngữ văn', 'Tin học'];

  const filteredCourses = courses.filter((course) => {
    const matchSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.instructor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.code.toLowerCase().includes(searchTerm.toLowerCase());

    const matchSubject =
      selectedSubject === 'Tất cả' || course.subject === selectedSubject;

    let matchProgress = true;
    if (filterProgress === 'in_progress') {
      matchProgress = course.progress < 100;
    } else if (filterProgress === 'completed') {
      matchProgress = course.progress === 100;
    }

    return matchSearch && matchSubject && matchProgress;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
            Khóa Học Của Tôi
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Quản lý và tiếp tục theo học các chuyên đề theo lộ trình ôn thi
          </p>
        </div>

        <button
          onClick={() => setIsEnrollModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#3E4C82]/20 transition-all active:scale-95 shrink-0"
        >
          <Plus size={17} />
          <span>Đăng Ký Khóa Học Mới</span>
        </button>
      </div>

      {/* Filter Controls Bar */}
      <div className="bg-white dark:bg-[#1C1F2E] p-4 sm:p-5 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs space-y-4">
        {/* Search input & Progress status filter */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search
              size={17}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm kiếm khóa học theo tên bài, mã môn hoặc giáo viên..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#3E4C82]"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setFilterProgress('all')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                filterProgress === 'all'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Tất cả ({courses.length})
            </button>
            <button
              onClick={() => setFilterProgress('in_progress')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                filterProgress === 'in_progress'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Đang học ({courses.filter(c => c.progress < 100).length})
            </button>
            <button
              onClick={() => setFilterProgress('completed')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                filterProgress === 'completed'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Đã xong ({courses.filter(c => c.progress === 100).length})
            </button>
          </div>
        </div>

        {/* Subject Category Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0 font-medium">
            <Filter size={13} />
            Môn:
          </span>
          {subjects.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                selectedSubject === sub
                  ? 'bg-[#E2A33D] text-slate-950 font-bold shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      {filteredCourses.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-[#1C1F2E] rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] space-y-3">
          <BookOpen size={48} className="mx-auto text-slate-300 dark:text-slate-600" />
          <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">
            Không tìm thấy khóa học nào
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Không có khóa học nào khớp với bộ lọc hiện tại. Bạn có thể xóa bộ lọc hoặc đăng ký khóa học mới.
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedSubject('Tất cả');
                setFilterProgress('all');
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold text-[#3E4C82] dark:text-[#8D81F2] bg-[#3E4C82]/10 hover:bg-[#3E4C82]/20"
            >
              Đặt lại bộ lọc
            </button>
            <button
              onClick={() => setIsEnrollModalOpen(true)}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#3E4C82] hover:bg-[#323D6B]"
            >
              Đăng ký khóa học mới
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => {
            const firstPendingLesson =
              course.chapters.flatMap(ch => ch.lessons).find(l => l.status !== 'completed') ||
              course.chapters[0]?.lessons[0];

            return (
              <motion.div
                key={course.id}
                whileHover={{ y: -4 }}
                transition={{ duration: 0.2 }}
                className="bg-white dark:bg-[#1C1F2E] rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] overflow-hidden shadow-xs hover:shadow-xl transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Thumbnail & Badges */}
                  <div
                    className="relative h-44 w-full bg-slate-900 overflow-hidden cursor-pointer"
                    onClick={() => setSelectedCourse(course)}
                  >
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                    {/* Top tags */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-lg bg-[#3E4C82] text-white text-[11px] font-bold font-mono shadow-md">
                        {course.subject}
                      </span>
                      <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-md text-yellow-400 text-[11px] font-bold font-mono">
                        <Star size={12} className="fill-yellow-400" />
                        <span>{course.rating}</span>
                      </div>
                    </div>

                    {/* Bottom Title inside Image */}
                    <div className="absolute bottom-3 left-3 right-3">
                      <p className="text-[11px] text-slate-300 font-mono">Mã: {course.code}</p>
                      <h3 className="font-bold font-heading text-sm text-white line-clamp-1">
                        {course.title}
                      </h3>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 sm:p-5 space-y-4">
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {course.description}
                    </p>

                    {/* Instructor Info */}
                    <div className="flex items-center gap-3">
                      <img
                        src={course.instructor.avatar}
                        alt={course.instructor.name}
                        className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                          {course.instructor.name}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate">
                          {course.instructor.title}
                        </p>
                      </div>
                    </div>

                    {/* Course Stats */}
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] font-mono text-slate-500 dark:text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Layers size={13} className="text-[#3E4C82] dark:text-[#8D81F2]" />
                        <span>{course.completedLessons}/{course.totalLessons} bài học</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock size={13} className="text-amber-500" />
                        <span>{course.durationHours} giờ học</span>
                      </div>
                    </div>

                    {/* Progress */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">Tiến độ</span>
                        <span className="font-bold text-[#3E4C82] dark:text-[#8D81F2]">
                          {course.progress}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#3E4C82] dark:bg-[#8D81F2] rounded-full transition-all duration-300"
                          style={{ width: `${course.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-4 sm:p-5 pt-0 flex items-center gap-2">
                  <button
                    onClick={() => setSelectedCourse(course)}
                    className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    Xem chi tiết
                  </button>

                  <button
                    onClick={() => {
                      if (firstPendingLesson) {
                        setActiveLesson({ course, lesson: firstPendingLesson });
                      } else {
                        setSelectedCourse(course);
                      }
                    }}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs font-bold shadow-md shadow-[#3E4C82]/20 transition-all active:scale-95"
                  >
                    <Play size={13} />
                    <span>{course.progress === 100 ? 'Ôn tập lại' : 'Học tiếp'}</span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
