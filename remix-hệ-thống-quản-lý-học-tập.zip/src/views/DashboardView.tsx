import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  BookOpen,
  Clock,
  Award,
  Flame,
  Plus,
  Play,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';
import { weeklyStudyHours } from '@/data/mockData';
import { motion } from 'motion/react';

export const DashboardView: React.FC = () => {
  const {
    user,
    courses,
    tasks,
    scheduleEvents,
    setSelectedCourse,
    setActiveLesson,
    updateTaskStatus,
    setIsNewTaskModalOpen,
    setIsEnrollModalOpen,
    setIsAIAssistantOpen,
    setCurrentView,
    badges
  } = useApp();

  // Stats calculation
  const totalCompletedLessons = courses.reduce((acc, c) => acc + c.completedLessons, 0);
  const totalLessons = courses.reduce((acc, c) => acc + c.totalLessons, 0);
  const overallCourseProgress = totalLessons > 0 ? Math.round((totalCompletedLessons / totalLessons) * 100) : 0;
  const pendingTasks = tasks.filter(t => t.status !== 'completed');
  const urgentTasks = pendingTasks.slice(0, 3);
  const upcomingEvents = scheduleEvents.slice(0, 3);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-[#262F52] via-[#3E4C82] to-[#5162A6] text-white shadow-xl overflow-hidden">
        {/* Abstract background graphics */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 skew-x-12 pointer-events-none" />
        <div className="absolute -right-10 -bottom-10 w-60 h-60 rounded-full bg-[#E2A33D]/20 blur-2xl pointer-events-none" />
        <div className="absolute top-4 right-1/4 w-32 h-32 rounded-full bg-[#7C6FE3]/20 blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold backdrop-blur-md text-[#E2A33D] border border-white/10">
              <Flame size={15} />
              <span>Chuỗi {user.streakDays} ngày học tập chăm chỉ!</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-heading tracking-tight text-white">
              Xin chào, {user.name}! 👋
            </h1>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              Mục tiêu hôm nay: Hoàn thành 2 bài học Toán & nộp bài tập Vật lý trước 22:00. Chúc bạn có một ngày học tập thật hứng khởi!
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap gap-2.5 sm:gap-3 shrink-0">
            <button
              onClick={() => setIsAIAssistantOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#7C6FE3] hover:bg-[#6A5CD6] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#7C6FE3]/30 transition-all active:scale-95 border border-white/20"
            >
              <Sparkles size={16} />
              <span>Hỏi AI Tutor</span>
            </button>

            <button
              onClick={() => setIsNewTaskModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs sm:text-sm font-bold backdrop-blur-md transition-all active:scale-95 border border-white/20"
            >
              <Plus size={16} />
              <span>Thêm Nhiệm Vụ</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Overview Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Khóa học */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Khóa học đang học
            </span>
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-[#3E4C82] dark:text-[#8D81F2] flex items-center justify-center">
              <BookOpen size={18} />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {courses.length}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Tiến độ chung: <span className="font-mono font-bold text-[#3E4C82] dark:text-[#8D81F2]">{overallCourseProgress}%</span>
            </p>
          </div>
        </div>

        {/* Card 2: Giờ học */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Giờ học tích lũy
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-[#E2A33D] flex items-center justify-center">
              <Clock size={18} />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              42.5h
            </div>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
              ↑ 18% so với tuần trước
            </p>
          </div>
        </div>

        {/* Card 3: Điểm thưởng & Level */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Điểm thưởng Edu
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-[#6E9E72] flex items-center justify-center">
              <Award size={18} />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {user.points}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Danh hiệu: <span className="font-semibold text-slate-700 dark:text-slate-300">Chiến binh ôn thi</span>
            </p>
          </div>
        </div>

        {/* Card 4: Bài tập còn hạn */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Bài tập cần nộp
            </span>
            <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-[#C56464] flex items-center justify-center">
              <AlertTriangle size={18} />
            </div>
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-[#C56464]">
              {pendingTasks.length}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Gồm {pendingTasks.filter(t => t.priority === 'high').length} bài ưu tiên cao
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 spans) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Chart: Thời gian học trong tuần */}
          <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-bold font-heading text-base text-slate-900 dark:text-white">
                  Thống Kê Giờ Học Trong Tuần
                </h3>
                <p className="text-xs text-slate-400">
                  Theo dõi thời lượng học tập trung mỗi ngày (giờ)
                </p>
              </div>
              <span className="text-xs font-mono font-bold px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-[#3E4C82] dark:text-[#8D81F2]">
                Tuần 42 (Học kỳ 1)
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyStudyHours} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#88888820" vertical={false} />
                  <XAxis dataKey="day" stroke="#888888" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#888888" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#262F52',
                      borderColor: '#3E4C82',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                      fontFamily: 'Inter, sans-serif'
                    }}
                    formatter={(value: any) => [`${value} giờ`, 'Thời gian học']}
                  />
                  <Bar dataKey="hours" fill="#3E4C82" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Active Courses Section */}
          <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-bold font-heading text-base text-slate-900 dark:text-white">
                  Khóa Học Đang Theo Học
                </h3>
                <p className="text-xs text-slate-400">
                  Chọn khóa học để xem nội dung bài giảng và làm bài tập
                </p>
              </div>
              <button
                onClick={() => setCurrentView('courses')}
                className="text-xs font-bold text-[#3E4C82] dark:text-[#8D81F2] hover:underline flex items-center gap-1"
              >
                <span>Xem tất cả</span>
                <ChevronRight size={14} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {courses.slice(0, 4).map((course) => {
                const firstPendingLesson =
                  course.chapters.flatMap(ch => ch.lessons).find(l => l.status !== 'completed') ||
                  course.chapters[0]?.lessons[0];

                return (
                  <motion.div
                    key={course.id}
                    whileHover={{ y: -2 }}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/40 hover:bg-white dark:hover:bg-slate-800/80 transition-all flex flex-col justify-between group cursor-pointer"
                    onClick={() => setSelectedCourse(course)}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2.5">
                        <span className="px-2 py-0.5 rounded-md bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] text-[10px] font-bold font-mono">
                          {course.subject}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">
                          {course.completedLessons}/{course.totalLessons} bài
                        </span>
                      </div>

                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white line-clamp-1 group-hover:text-[#3E4C82] dark:group-hover:text-[#8D81F2] transition-colors">
                        {course.title}
                      </h4>

                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-1">
                        Giảng viên: {course.instructor.name}
                      </p>

                      {/* Progress bar */}
                      <div className="mt-3.5 space-y-1">
                        <div className="flex justify-between text-[11px] font-mono">
                          <span className="text-slate-400">Tiến độ</span>
                          <span className="font-bold text-[#3E4C82] dark:text-[#8D81F2]">
                            {course.progress}%
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#3E4C82] dark:bg-[#8D81F2] rounded-full transition-all duration-300"
                            style={{ width: `${course.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400">
                        {course.lastAccessed ? `Học gần nhất: ${course.lastAccessed}` : 'Chưa bắt đầu'}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (firstPendingLesson) {
                            setActiveLesson({ course, lesson: firstPendingLesson });
                          } else {
                            setSelectedCourse(course);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-[#3E4C82] text-white hover:bg-[#323D6B] text-xs transition-colors flex items-center gap-1 font-semibold px-2.5"
                      >
                        <Play size={12} />
                        <span>Học tiếp</span>
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (1 span) */}
        <div className="space-y-6">
          {/* Upcoming Live Classes & Events */}
          <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold font-heading text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar size={17} className="text-[#3E4C82] dark:text-[#8D81F2]" />
                <span>Lịch Học Sắp Tới</span>
              </h3>
              <button
                onClick={() => setCurrentView('schedule')}
                className="text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline"
              >
                Chi tiết
              </button>
            </div>

            <div className="space-y-3">
              {upcomingEvents.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">Không có lịch học sắp tới.</p>
              ) : (
                upcomingEvents.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-md bg-[#E2A33D]/15 text-[#C88E32] dark:text-[#E2A33D] text-[10px] font-bold font-mono">
                        {evt.subject}
                      </span>
                      <span className="text-[11px] font-mono font-semibold text-slate-600 dark:text-slate-300">
                        {evt.startTime} - {evt.endTime}
                      </span>
                    </div>

                    <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                      {evt.title}
                    </h4>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                      <span>{evt.instructor}</span>
                      {evt.type === 'online' ? (
                        <span className="text-[#3E4C82] dark:text-[#8D81F2] font-semibold flex items-center gap-1">
                          <ExternalLink size={11} />
                          Online Meet
                        </span>
                      ) : (
                        <span>{evt.location}</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Urgent Homework / Tasks */}
          <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold font-heading text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle size={17} className="text-[#C56464]" />
                <span>Bài Tập Gấp Cần Nộp</span>
              </h3>
              <button
                onClick={() => setCurrentView('tasks')}
                className="text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline"
              >
                Kanban
              </button>
            </div>

            <div className="space-y-2.5">
              {urgentTasks.length === 0 ? (
                <div className="text-center py-4 text-xs text-slate-400">
                  🎉 Tuyệt vời! Không còn bài tập nào còn nợ.
                </div>
              ) : (
                urgentTasks.map((task) => (
                  <div
                    key={task.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 flex items-start gap-3 group"
                  >
                    <button
                      onClick={() => updateTaskStatus(task.id, 'completed')}
                      className="mt-0.5 text-slate-400 hover:text-emerald-500 transition-colors shrink-0"
                      title="Đánh dấu hoàn thành bài tập"
                      aria-label="Hoàn thành bài tập"
                    >
                      <CheckCircle2 size={18} />
                    </button>

                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-[11px] font-mono text-slate-400">
                        <span>{task.subject}</span>
                        <span>•</span>
                        <span className="text-rose-500 font-semibold">Hạn: {task.dueDate}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setIsNewTaskModalOpen(true)}
              className="w-full mt-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors flex items-center justify-center gap-1.5"
            >
              <Plus size={14} />
              <span>Thêm nhiệm vụ mới</span>
            </button>
          </div>

          {/* Badges Preview */}
          <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold font-heading text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Award size={17} className="text-[#E2A33D]" />
                <span>Huy Hiệu Đạt Được</span>
              </h3>
              <button
                onClick={() => setCurrentView('profile')}
                className="text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline"
              >
                Tất cả
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {badges.filter(b => b.unlocked).slice(0, 4).map((badge) => (
                <div
                  key={badge.id}
                  className="p-3 rounded-2xl bg-[#E2A33D]/5 dark:bg-[#E2A33D]/10 border border-[#E2A33D]/20 flex items-center gap-2.5"
                >
                  <span className="text-2xl">{badge.icon}</span>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {badge.title}
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono">
                      +{badge.pointsReward} pts
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
