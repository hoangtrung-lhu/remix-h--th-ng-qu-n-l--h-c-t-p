import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Bell,
  CheckCheck,
  BookOpen,
  Award,
  AlertTriangle,
  Info,
  Clock,
  Trash2
} from 'lucide-react';
import { motion } from 'motion/react';

export const NotificationsView: React.FC = () => {
  const {
    notifications,
    unreadNotificationCount,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    setCurrentView
  } = useApp();

  const [filterTab, setFilterTab] = useState<'all' | 'unread' | 'assignment' | 'system' | 'achievement'>('all');

  const filteredNotifications = notifications.filter((item) => {
    if (filterTab === 'unread') return !item.read;
    if (filterTab === 'assignment') return item.type === 'assignment';
    if (filterTab === 'system') return item.type === 'system';
    if (filterTab === 'achievement') return item.type === 'achievement';
    return true;
  });

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'assignment':
        return <BookOpen size={18} className="text-[#3E4C82] dark:text-[#8D81F2]" />;
      case 'achievement':
        return <Award size={18} className="text-[#E2A33D]" />;
      case 'alert':
        return <AlertTriangle size={18} className="text-[#C56464]" />;
      default:
        return <Info size={18} className="text-indigo-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
            Trung Tâm Thông Báo
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Cập nhật tin tức khóa học, hạn nộp bài tập và phần thưởng học tập
          </p>
        </div>

        {unreadNotificationCount > 0 && (
          <button
            onClick={markAllNotificationsAsRead}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors shrink-0"
          >
            <CheckCheck size={16} />
            <span>Đánh dấu tất cả đã đọc</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="bg-white dark:bg-[#1C1F2E] p-2 rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setFilterTab('all')}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            filterTab === 'all'
              ? 'bg-[#3E4C82] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Tất cả ({notifications.length})
        </button>

        <button
          onClick={() => setFilterTab('unread')}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            filterTab === 'unread'
              ? 'bg-[#3E4C82] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <span>Chưa đọc</span>
          {unreadNotificationCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-[#C56464] text-white text-[10px] font-bold flex items-center justify-center font-mono">
              {unreadNotificationCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setFilterTab('assignment')}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            filterTab === 'assignment'
              ? 'bg-[#3E4C82] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Bài tập & Khóa học
        </button>

        <button
          onClick={() => setFilterTab('achievement')}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            filterTab === 'achievement'
              ? 'bg-[#3E4C82] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Thành tích
        </button>

        <button
          onClick={() => setFilterTab('system')}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            filterTab === 'system'
              ? 'bg-[#3E4C82] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Hệ thống
        </button>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-[#1C1F2E] rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] space-y-2">
            <Bell size={40} className="mx-auto text-slate-300 dark:text-slate-600 mb-2" />
            <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
              Không có thông báo nào trong mục này
            </h4>
            <p className="text-xs text-slate-400">
              Bạn đã xem hết các thông báo mới nhất.
            </p>
          </div>
        ) : (
          filteredNotifications.map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => {
                markNotificationAsRead(item.id);
                if (item.actionView) {
                  setCurrentView(item.actionView);
                }
              }}
              className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 ${
                !item.read
                  ? 'bg-white dark:bg-[#1C1F2E] border-[#3E4C82]/30 shadow-sm'
                  : 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-800/80 opacity-85'
              } hover:border-[#3E4C82]`}
            >
              <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                {getNotifIcon(item.type)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                      <Clock size={11} />
                      {item.timeAgo}
                    </span>
                    {!item.read && (
                      <span className="w-2.5 h-2.5 rounded-full bg-[#3E4C82] dark:bg-[#8D81F2]" />
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {item.message}
                </p>

                {item.actionView && (
                  <button className="mt-2 text-xs font-semibold text-[#3E4C82] dark:text-[#8D81F2] hover:underline">
                    👉 Xem chi tiết ngay
                  </button>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
