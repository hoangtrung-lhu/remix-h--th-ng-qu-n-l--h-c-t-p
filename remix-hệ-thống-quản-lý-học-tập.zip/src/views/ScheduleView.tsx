import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Calendar as CalendarIcon,
  Plus,
  Clock,
  ExternalLink,
  Trash2,
  Filter,
  ChevronLeft,
  ChevronRight,
  Video,
  School,
  FileCheck,
  BookOpen
} from 'lucide-react';
import { ScheduleEvent } from '@/types';
import { motion } from 'motion/react';

export const ScheduleView: React.FC = () => {
  const {
    scheduleEvents,
    deleteScheduleEvent,
    setIsNewEventModalOpen
  } = useApp();

  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  // Days in current week
  const getDaysOfWeek = (currentDateStr: string) => {
    const curr = new Date(currentDateStr);
    const day = curr.getDay(); // 0 is Sunday
    const diff = curr.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    const monday = new Date(curr.setDate(diff));

    const weekDays = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const isoStr = d.toISOString().split('T')[0];
      const dayNames = ['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật'];
      weekDays.push({
        date: isoStr,
        dayName: dayNames[i],
        dayNumber: d.getDate(),
        month: d.getMonth() + 1
      });
    }
    return weekDays;
  };

  const weekDays = getDaysOfWeek(selectedDate);

  const filteredEvents = scheduleEvents.filter((event) => {
    const matchType = selectedType === 'all' || event.type === selectedType;
    return matchType;
  });

  const getEventsForDay = (dateStr: string) => {
    return filteredEvents.filter((e) => e.date === dateStr);
  };

  const selectedDayEvents = getEventsForDay(selectedDate);

  const handleNextWeek = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 7);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handlePrevWeek = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 7);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  const getEventIcon = (type: ScheduleEvent['type']) => {
    switch (type) {
      case 'online':
        return <Video size={16} className="text-[#3E4C82] dark:text-[#8D81F2]" />;
      case 'offline':
        return <School size={16} className="text-[#E2A33D]" />;
      case 'exam':
        return <FileCheck size={16} className="text-[#C56464]" />;
      default:
        return <BookOpen size={16} className="text-[#6E9E72]" />;
    }
  };

  const getEventBadge = (type: ScheduleEvent['type']) => {
    switch (type) {
      case 'online':
        return 'bg-indigo-500/10 text-[#3E4C82] dark:text-[#8D81F2] border-indigo-500/20';
      case 'offline':
        return 'bg-amber-500/10 text-[#E2A33D] border-amber-500/20';
      case 'exam':
        return 'bg-rose-500/10 text-[#C56464] border-rose-500/20';
      default:
        return 'bg-emerald-500/10 text-[#6E9E72] border-emerald-500/20';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
            Thời Khóa Biểu & Lịch Học
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Theo dõi các buổi học trực tuyến, lịch thi thử và tự học cá nhân
          </p>
        </div>

        <button
          onClick={() => setIsNewEventModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#3E4C82]/20 transition-all active:scale-95 shrink-0"
        >
          <Plus size={17} />
          <span>Thêm Lịch Học Mới</span>
        </button>
      </div>

      {/* Week Navigator & Filter */}
      <div className="bg-white dark:bg-[#1C1F2E] p-4 sm:p-6 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs space-y-4">
        {/* Navigation buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevWeek}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
              aria-label="Tuần trước"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={handleToday}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Hôm nay
            </button>
            <button
              onClick={handleNextWeek}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
              aria-label="Tuần sau"
            >
              <ChevronRight size={18} />
            </button>

            <span className="text-xs sm:text-sm font-bold font-heading text-slate-800 dark:text-slate-200 ml-2">
              Tháng {new Date(selectedDate).getMonth() + 1}, {new Date(selectedDate).getFullYear()}
            </span>
          </div>

          {/* Type filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0 mr-1">
              <Filter size={13} />
              Lọc:
            </span>
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedType === 'all'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Tất cả
            </button>
            <button
              onClick={() => setSelectedType('online')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedType === 'online'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Trực tuyến
            </button>
            <button
              onClick={() => setSelectedType('offline')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedType === 'offline'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Tại lớp
            </button>
            <button
              onClick={() => setSelectedType('exam')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedType === 'exam'
                  ? 'bg-[#3E4C82] text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              Thi thử
            </button>
          </div>
        </div>

        {/* 7 Days of the Week Selector */}
        <div className="grid grid-cols-7 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          {weekDays.map((day) => {
            const isSelected = selectedDate === day.date;
            const isToday = new Date().toISOString().split('T')[0] === day.date;
            const eventsCount = getEventsForDay(day.date).length;

            return (
              <button
                key={day.date}
                onClick={() => setSelectedDate(day.date)}
                className={`p-3 rounded-2xl flex flex-col items-center justify-between gap-1 transition-all ${
                  isSelected
                    ? 'bg-[#3E4C82] text-white shadow-md shadow-[#3E4C82]/30 scale-102'
                    : 'bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className={`text-[11px] font-medium ${isSelected ? 'text-white/80' : 'text-slate-400'}`}>
                  {day.dayName}
                </span>
                <span className={`text-base sm:text-lg font-bold font-mono ${isToday && !isSelected ? 'text-[#E2A33D]' : ''}`}>
                  {day.dayNumber}
                </span>
                <div className="h-2 flex items-center justify-center">
                  {eventsCount > 0 && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isSelected ? 'bg-[#E2A33D]' : 'bg-[#3E4C82] dark:bg-[#8D81F2]'
                      }`}
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Events List for Selected Day */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold font-heading text-base text-slate-900 dark:text-white flex items-center gap-2">
            <CalendarIcon size={18} className="text-[#3E4C82] dark:text-[#8D81F2]" />
            <span>
              Lịch trình ngày {new Date(selectedDate).toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
          </h3>
          <span className="text-xs font-mono text-slate-400">
            {selectedDayEvents.length} sự kiện
          </span>
        </div>

        {selectedDayEvents.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-[#1C1F2E] rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] space-y-3">
            <CalendarIcon size={44} className="mx-auto text-slate-300 dark:text-slate-600" />
            <h4 className="font-bold text-base text-slate-800 dark:text-slate-200">
              Không có lịch học nào trong ngày này
            </h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Bạn có thể tự do nghỉ ngơi hoặc đặt lịch tự học để tối ưu hóa thời gian.
            </p>
            <button
              onClick={() => setIsNewEventModalOpen(true)}
              className="mt-2 px-5 py-2.5 rounded-xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs font-bold shadow-sm"
            >
              + Thêm lịch học ngay
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selectedDayEvents.map((event) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white dark:bg-[#1C1F2E] p-5 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs space-y-4 hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar */}
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-lg bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] text-xs font-bold font-mono">
                        {event.subject}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-lg text-xs font-semibold border flex items-center gap-1 ${getEventBadge(event.type)}`}>
                        {getEventIcon(event.type)}
                        <span>
                          {event.type === 'online' ? 'Online' : event.type === 'offline' ? 'Tại lớp' : event.type === 'exam' ? 'Thi thử' : 'Tự học'}
                        </span>
                      </span>
                    </div>

                    <button
                      onClick={() => deleteScheduleEvent(event.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                      title="Xóa lịch học"
                      aria-label="Xóa lịch học"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>

                  {/* Title */}
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">
                    {event.title}
                  </h4>

                  {/* Time */}
                  <div className="flex items-center gap-2 mt-2 text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">
                    <Clock size={14} className="text-[#E2A33D]" />
                    <span>{event.startTime} - {event.endTime}</span>
                  </div>

                  {/* Instructor & Location */}
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <p className="flex items-center justify-between">
                      <span>Người phụ trách:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{event.instructor}</span>
                    </p>
                    <p className="flex items-center justify-between">
                      <span>Địa điểm / Link:</span>
                      <span className="font-mono text-slate-700 dark:text-slate-300 truncate max-w-[200px]">{event.location}</span>
                    </p>
                  </div>
                </div>

                {/* Footer Join Button */}
                {event.type === 'online' ? (
                  <a
                    href="https://meet.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 rounded-xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md shadow-[#3E4C82]/20 transition-all active:scale-95 mt-2"
                  >
                    <ExternalLink size={14} />
                    <span>Vào phòng học trực tuyến (Meet)</span>
                  </a>
                ) : (
                  <div className="p-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-center text-xs font-medium text-slate-600 dark:text-slate-400 mt-2">
                    📍 {event.location}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
