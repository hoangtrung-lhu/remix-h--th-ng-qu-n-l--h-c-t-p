import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  User,
  Settings as SettingsIcon,
  Award,
  Sun,
  Moon,
  Save,
  CheckCircle2,
  Lock,
  Sparkles,
  Flame,
  ShieldCheck,
  BellRing
} from 'lucide-react';
import { motion } from 'motion/react';

export const SettingsView: React.FC = () => {
  const {
    user,
    updateUserProfile,
    darkMode,
    toggleDarkMode,
    badges
  } = useApp();

  const [activeTab, setActiveTab] = useState<'profile' | 'settings' | 'badges'>('profile');

  // Profile Form state
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone || '0987 654 321');
  const [school, setSchool] = useState(user.school);
  const [grade, setGrade] = useState(user.grade);
  const [targetScore, setTargetScore] = useState(user.targetScore || '27.5+ Khối A00');
  const [bio, setBio] = useState(user.bio || 'Học sinh lớp 12 quyết tâm đỗ Đại học Bách Khoa Hà Nội.');
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      updateUserProfile({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        school: school.trim(),
        grade: grade.trim(),
        targetScore: targetScore.trim(),
        bio: bio.trim()
      });
      setIsSaving(false);
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
          Hồ Sơ Cá Nhân & Cài Đặt
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Quản lý thông tin học viên, tùy chỉnh giao diện và xem bộ sưu tập huy hiệu
        </p>
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-[#1C1F2E] p-2 rounded-2xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
            activeTab === 'profile'
              ? 'bg-[#3E4C82] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <User size={16} />
          <span>Hồ Sơ Học Viên</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
            activeTab === 'settings'
              ? 'bg-[#3E4C82] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <SettingsIcon size={16} />
          <span>Giao Diện & Hệ Thống</span>
        </button>

        <button
          onClick={() => setActiveTab('badges')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
            activeTab === 'badges'
              ? 'bg-[#3E4C82] text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Award size={16} />
          <span>Huy Hiệu & Thành Tích ({badges.filter(b => b.unlocked).length}/{badges.length})</span>
        </button>
      </div>

      {/* Tab 1: Hồ Sơ Cá Nhân */}
      {activeTab === 'profile' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#1C1F2E] p-6 sm:p-8 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs space-y-6"
        >
          {/* User Top Card */}
          <div className="flex flex-col sm:flex-row items-center gap-5 p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-20 h-20 rounded-2xl object-cover ring-4 ring-[#3E4C82]/20"
              />
              <span className="absolute -bottom-1 -right-1 p-1 bg-[#E2A33D] text-slate-950 rounded-lg text-[10px] font-bold">
                PRO
              </span>
            </div>

            <div className="text-center sm:text-left space-y-1 flex-1 min-w-0">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h3 className="font-bold text-lg font-heading text-slate-900 dark:text-white">
                  {user.name}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] text-xs font-mono font-bold">
                  {user.grade}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {user.school} • {user.email}
              </p>
              <div className="flex items-center justify-center sm:justify-start gap-3 pt-1 text-xs font-mono">
                <span className="flex items-center gap-1 text-[#E2A33D] font-bold">
                  <Flame size={14} /> {user.streakDays} ngày streak
                </span>
                <span className="text-slate-400">•</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  {user.points} Điểm thưởng
                </span>
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Họ và tên học viên <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-[#3E4C82]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Địa chỉ Email <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-[#3E4C82]"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Số điện thoại
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Trường THPT
                </label>
                <input
                  type="text"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Khối Lớp
                </label>
                <input
                  type="text"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Mục tiêu điểm số thi tốt nghiệp / ĐH
              </label>
              <input
                type="text"
                value={targetScore}
                onChange={(e) => setTargetScore(e.target.value)}
                placeholder="VD: 28+ Khối A00 (ĐH Bách Khoa)"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Lời nhắn tự nhủ / Giới thiệu bản thân
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white leading-relaxed"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#3E4C82]/20 transition-all active:scale-95 disabled:opacity-50"
              >
                <Save size={16} />
                <span>{isSaving ? 'Đang lưu...' : 'Lưu Thay Đổi'}</span>
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Tab 2: Giao Diện & Hệ Thống */}
      {activeTab === 'settings' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-[#1C1F2E] p-6 sm:p-8 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs space-y-6"
        >
          {/* Dark / Light Mode Switch */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                {darkMode ? <Moon size={20} className="text-[#E2A33D]" /> : <Sun size={20} className="text-[#3E4C82]" />}
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Chế độ hiển thị: {darkMode ? 'Tối (Dark Mode)' : 'Sáng (Light Mode)'}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Tùy chỉnh tông màu bảo vệ mắt khi học tập ban đêm
                </p>
              </div>
            </div>

            <button
              onClick={toggleDarkMode}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                darkMode
                  ? 'bg-[#E2A33D] text-slate-950'
                  : 'bg-[#3E4C82] text-white shadow-xs'
              }`}
            >
              {darkMode ? '☀️ Chuyển sang Sáng' : '🌙 Chuyển sang Tối'}
            </button>
          </div>

          {/* Notifications toggles */}
          <div className="space-y-3">
            <h4 className="font-bold font-heading text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <BellRing size={17} className="text-[#3E4C82] dark:text-[#8D81F2]" />
              <span>Cài đặt thông báo & Nhắc nhở</span>
            </h4>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden">
              <div className="p-4 bg-slate-50/50 dark:bg-slate-900/30 flex items-center justify-between">
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Nhắc nhở hạn nộp bài tập trước 24 giờ
                  </p>
                  <p className="text-xs text-slate-400">Gửi thông báo trên thanh thông báo</p>
                </div>
                <input type="checkbox" defaultChecked className="accent-[#3E4C82] w-4 h-4 cursor-pointer" />
              </div>

              <div className="p-4 bg-slate-50/50 dark:bg-slate-900/30 flex items-center justify-between">
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Nhắc nhở phòng học trực tuyến trước 15 phút
                  </p>
                  <p className="text-xs text-slate-400">Thông báo vào phòng Google Meet</p>
                </div>
                <input type="checkbox" defaultChecked className="accent-[#3E4C82] w-4 h-4 cursor-pointer" />
              </div>

              <div className="p-4 bg-slate-50/50 dark:bg-slate-900/30 flex items-center justify-between">
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Âm thanh chúc mừng khi hoàn thành bài học
                  </p>
                  <p className="text-xs text-slate-400">Hiệu ứng âm thanh tăng động lực</p>
                </div>
                <input type="checkbox" defaultChecked className="accent-[#3E4C82] w-4 h-4 cursor-pointer" />
              </div>
            </div>
          </div>

          {/* System info */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/50 dark:border-indigo-900/50 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <ShieldCheck size={18} className="text-[#3E4C82] dark:text-[#8D81F2]" />
              <span>Phiên bản EduLMS 2.4.0 (Tiếng Việt) • Dữ liệu lưu tự động</span>
            </div>
            <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
              Đồng bộ hoàn tất
            </span>
          </div>
        </motion.div>
      )}

      {/* Tab 3: Huy Hiệu & Thành Tích */}
      {activeTab === 'badges' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] flex items-center justify-between">
            <div>
              <h3 className="font-bold font-heading text-base text-slate-900 dark:text-white">
                Bộ Sưu Tập Thành Tích
              </h3>
              <p className="text-xs text-slate-400">
                Tích lũy điểm thưởng và mở khóa danh hiệu độc quyền khi chăm chỉ học tập
              </p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold font-mono text-[#E2A33D]">{user.points} pts</p>
              <p className="text-[11px] text-slate-400">Tổng điểm tích lũy</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {badges.map((badge) => {
              return (
                <div
                  key={badge.id}
                  className={`p-5 rounded-3xl border transition-all flex flex-col justify-between ${
                    badge.unlocked
                      ? 'bg-white dark:bg-[#1C1F2E] border-[#E2A33D]/40 shadow-xs'
                      : 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-800 opacity-60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-3xl">{badge.icon}</span>
                      {badge.unlocked ? (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold font-mono flex items-center gap-1">
                          <CheckCircle2 size={11} /> Đã đạt
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-500 text-[10px] font-bold font-mono flex items-center gap-1">
                          <Lock size={10} /> Chưa mở
                        </span>
                      )}
                    </div>

                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      {badge.title}
                    </h4>

                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                      {badge.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-[#E2A33D] font-bold">+{badge.pointsReward} Điểm</span>
                    <span className="text-slate-400">
                      {badge.unlocked ? badge.unlockedAt : 'Cần đạt điều kiện'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}
    </div>
  );
};
