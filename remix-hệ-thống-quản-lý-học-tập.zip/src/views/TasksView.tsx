import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Plus,
  CheckCircle2,
  Trash2,
  Clock,
  Filter,
  ArrowRight,
  ArrowLeft,
  LayoutGrid,
  List,
  AlertCircle
} from 'lucide-react';
import { Task } from '@/types';
import { motion, AnimatePresence } from 'motion/react';

export const TasksView: React.FC = () => {
  const {
    tasks,
    updateTaskStatus,
    deleteTask,
    setIsNewTaskModalOpen
  } = useApp();

  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');

  const subjects = ['all', 'Toán 12', 'Vật lý 12', 'Hóa học 12', 'Tiếng Anh', 'Ngữ văn 12', 'Tin học'];

  const filteredTasks = tasks.filter((task) => {
    const matchSub = selectedSubject === 'all' || task.subject === selectedSubject;
    const matchPri = selectedPriority === 'all' || task.priority === selectedPriority;
    return matchSub && matchPri;
  });

  const todoTasks = filteredTasks.filter((t) => t.status === 'todo');
  const inProgressTasks = filteredTasks.filter((t) => t.status === 'in_progress');
  const completedTasks = filteredTasks.filter((t) => t.status === 'completed');

  const getPriorityBadge = (priority: Task['priority']) => {
    switch (priority) {
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded-md bg-rose-500/10 text-[#C56464] border border-rose-500/20 text-[10px] font-bold">
            🔴 Gấp
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-[#E2A33D] border border-amber-500/20 text-[10px] font-bold">
            🟡 Vừa
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-[#6E9E72] border border-emerald-500/20 text-[10px] font-bold">
            🟢 Thường
          </span>
        );
    }
  };

  const renderTaskCard = (task: Task) => {
    return (
      <motion.div
        key={task.id}
        layout
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="p-4 rounded-2xl bg-white dark:bg-[#1C1F2E] border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs hover:shadow-md transition-shadow space-y-3"
      >
        {/* Card Header */}
        <div className="flex items-center justify-between gap-2">
          <span className="px-2 py-0.5 rounded-md bg-[#3E4C82]/10 dark:bg-[#5162A6]/20 text-[#3E4C82] dark:text-[#8D81F2] text-[11px] font-bold font-mono">
            {task.subject}
          </span>
          <div className="flex items-center gap-1.5">
            {getPriorityBadge(task.priority)}
            <button
              onClick={() => deleteTask(task.id)}
              className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
              title="Xóa nhiệm vụ"
              aria-label="Xóa nhiệm vụ"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        {/* Title & Desc */}
        <div>
          <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-snug">
            {task.title}
          </h4>
          {task.description && (
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              {task.description}
            </p>
          )}
        </div>

        {/* Due date & Estimated time */}
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="text-rose-500 font-semibold">
            Hạn: {task.dueDate}
          </span>
          {task.estimatedMinutes && (
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {task.estimatedMinutes}p
            </span>
          )}
        </div>

        {/* Move buttons */}
        <div className="flex items-center justify-between pt-1 gap-1.5">
          {task.status === 'todo' && (
            <>
              <button
                onClick={() => updateTaskStatus(task.id, 'in_progress')}
                className="flex-1 py-1.5 px-2 rounded-lg bg-amber-500/10 text-[#E2A33D] hover:bg-amber-500/20 text-xs font-semibold flex items-center justify-center gap-1"
              >
                <span>Bắt đầu làm</span>
                <ArrowRight size={13} />
              </button>
              <button
                onClick={() => updateTaskStatus(task.id, 'completed')}
                className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20"
                title="Đánh dấu xong"
                aria-label="Đánh dấu xong"
              >
                <CheckCircle2 size={16} />
              </button>
            </>
          )}

          {task.status === 'in_progress' && (
            <>
              <button
                onClick={() => updateTaskStatus(task.id, 'todo')}
                className="py-1.5 px-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 text-xs font-semibold flex items-center gap-1"
                title="Quay lại cần làm"
                aria-label="Quay lại cần làm"
              >
                <ArrowLeft size={13} />
              </button>
              <button
                onClick={() => updateTaskStatus(task.id, 'completed')}
                className="flex-1 py-1.5 px-2 rounded-lg bg-[#6E9E72] hover:bg-[#5C8960] text-white text-xs font-bold flex items-center justify-center gap-1 shadow-sm"
              >
                <CheckCircle2 size={14} />
                <span>Hoàn thành (+30đ)</span>
              </button>
            </>
          )}

          {task.status === 'completed' && (
            <div className="w-full flex items-center justify-between">
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 size={13} /> Đã hoàn tất
              </span>
              <button
                onClick={() => updateTaskStatus(task.id, 'in_progress')}
                className="text-[10px] text-slate-400 hover:underline"
              >
                Làm lại
              </button>
            </div>
          )}
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white">
            Nhiệm Vụ & Bài Tập (Kanban)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Kéo chuyển trạng thái bài tập và quản lý deadline ôn thi hiệu quả
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View switcher */}
          <div className="flex items-center p-1 bg-white dark:bg-[#1C1F2E] rounded-xl border border-[#E2E0D8] dark:border-[#2D3349]">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'kanban'
                  ? 'bg-[#3E4C82] text-white'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
              title="Dạng Kanban"
              aria-label="Dạng Kanban"
            >
              <LayoutGrid size={16} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list'
                  ? 'bg-[#3E4C82] text-white'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
              }`}
              title="Dạng Danh Sách"
              aria-label="Dạng Danh Sách"
            >
              <List size={16} />
            </button>
          </div>

          <button
            onClick={() => setIsNewTaskModalOpen(true)}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-[#3E4C82] hover:bg-[#323D6B] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#3E4C82]/20 transition-all active:scale-95 shrink-0"
          >
            <Plus size={17} />
            <span>Thêm Bài Tập Mới</span>
          </button>
        </div>
      </div>

      {/* Filter Controls Bar */}
      <div className="bg-white dark:bg-[#1C1F2E] p-4 rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto">
          <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0 font-medium">
            <Filter size={13} />
            Môn học:
          </span>
          {subjects.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedSubject === sub
                  ? 'bg-[#3E4C82] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {sub === 'all' ? 'Tất cả' : sub}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Độ ưu tiên:</span>
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
          >
            <option value="all">Tất cả độ ưu tiên</option>
            <option value="high">🔴 Gấp (Cao)</option>
            <option value="medium">🟡 Trung bình</option>
            <option value="low">🟢 Thấp</option>
          </select>
        </div>
      </div>

      {/* Kanban Board View */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Column 1: Cần làm */}
          <div className="bg-slate-50/70 dark:bg-slate-900/40 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                <h3 className="font-bold font-heading text-sm text-slate-800 dark:text-slate-200">
                  Cần Làm
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                {todoTasks.length}
              </span>
            </div>

            <div className="space-y-3 min-h-[250px]">
              <AnimatePresence>
                {todoTasks.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
                    Không có bài tập cần làm
                  </div>
                ) : (
                  todoTasks.map((t) => renderTaskCard(t))
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Column 2: Đang thực hiện */}
          <div className="bg-amber-500/5 dark:bg-amber-500/5 p-4 rounded-3xl border border-amber-500/20 space-y-4">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#E2A33D] animate-pulse" />
                <h3 className="font-bold font-heading text-sm text-[#E2A33D]">
                  Đang Thực Hiện
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-xs font-mono font-bold text-[#E2A33D]">
                {inProgressTasks.length}
              </span>
            </div>

            <div className="space-y-3 min-h-[250px]">
              <AnimatePresence>
                {inProgressTasks.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-amber-500/20 rounded-2xl">
                    Chưa có bài tập nào đang tiến hành
                  </div>
                ) : (
                  inProgressTasks.map((t) => renderTaskCard(t))
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Column 3: Đã hoàn thành */}
          <div className="bg-emerald-500/5 dark:bg-emerald-500/5 p-4 rounded-3xl border border-emerald-500/20 space-y-4">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#6E9E72]" />
                <h3 className="font-bold font-heading text-sm text-[#6E9E72]">
                  Đã Hoàn Thành
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-xs font-mono font-bold text-[#6E9E72]">
                {completedTasks.length}
              </span>
            </div>

            <div className="space-y-3 min-h-[250px]">
              <AnimatePresence>
                {completedTasks.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-emerald-500/20 rounded-2xl">
                    Chưa có bài tập nào hoàn thành
                  </div>
                ) : (
                  completedTasks.map((t) => renderTaskCard(t))
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      ) : (
        /* List View */
        <div className="bg-white dark:bg-[#1C1F2E] rounded-3xl border border-[#E2E0D8] dark:border-[#2D3349] divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
          {filteredTasks.length === 0 ? (
            <div className="p-12 text-center text-slate-400">
              Không có bài tập nào phù hợp.
            </div>
          ) : (
            filteredTasks.map((task) => (
              <div
                key={task.id}
                className="p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() =>
                      updateTaskStatus(
                        task.id,
                        task.status === 'completed' ? 'todo' : 'completed'
                      )
                    }
                    className="text-slate-400 hover:text-emerald-500 shrink-0"
                    aria-label={task.status === 'completed' ? 'Đánh dấu chưa hoàn thành' : 'Đánh dấu hoàn thành'}
                  >
                    <CheckCircle2
                      size={20}
                      className={task.status === 'completed' ? 'text-emerald-500' : ''}
                    />
                  </button>

                  <div className="min-w-0">
                    <p
                      className={`text-xs sm:text-sm font-bold truncate ${
                        task.status === 'completed'
                          ? 'line-through text-slate-400'
                          : 'text-slate-900 dark:text-white'
                      }`}
                    >
                      {task.title}
                    </p>
                    <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400 mt-0.5">
                      <span>{task.subject}</span>
                      <span>•</span>
                      <span>Hạn: {task.dueDate}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  {getPriorityBadge(task.priority)}
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-500/10"
                    aria-label="Xóa nhiệm vụ"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
